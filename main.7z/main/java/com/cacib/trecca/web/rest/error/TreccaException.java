package com.cacib.trecca.web.rest.error;

public class TreccaException extends RuntimeException {

	private static final long serialVersionUID = -4803452152966321407L;

	public TreccaException(String message) {
		super(message);
	}
}
