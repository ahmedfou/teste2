package com.cacib.trecca.web.rest;

import com.cacib.trecca.service.TreccaService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.io.IOException;

@RestController
@RequiredArgsConstructor
@RequestMapping("api/v1")
public class TreccaResource {

	private final TreccaService treccaService;

	/**
	 * Trigger data processing by TRECCA
	 * @return A message with OK status if no issue
	 * @throws IOException if any issue occur
	 */
	@PostMapping(path = "/micro-vacation")
	public ResponseEntity<Void> microVacation() throws IOException {
		treccaService.microVacation();
		return ResponseEntity.ok().build();
	}

	@PostMapping(path = "/archive-referential")
	public ResponseEntity<Void> archiveReferential() {
		treccaService.archiveReferential();
		return ResponseEntity.ok().build();
	}
}
