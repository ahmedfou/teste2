package com.cacib.trecca.web.rest.error.handler;

import com.cacib.trecca.service.MessageServiceException;
import com.cacib.trecca.web.rest.error.TreccaException;
import com.cacib.trecca.web.rest.error.dto.ErrorDTO;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.context.request.NativeWebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import static org.springframework.http.HttpStatus.BAD_REQUEST;
import static org.springframework.http.HttpStatus.INTERNAL_SERVER_ERROR;

@Slf4j
@RestControllerAdvice
public class ExceptionTranslator extends ResponseEntityExceptionHandler {

    @ExceptionHandler(value = MessageServiceException.class)
    public ResponseEntity<Void> handleMessageServiceException(MessageServiceException exception) {
        log.error(exception.getMessage(), exception);
        // TODO: send email with message attached (do this in the exception handler
        return ResponseEntity.badRequest().build();
    }

    @ExceptionHandler(value = {TreccaException.class})
    public ResponseEntity<ErrorDTO> handleTreccaException(TreccaException exception) {
        log.error("Handling TreccaException", exception);
        var headers = new HttpHeaders();
        headers.add(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE);
        var errorDTO = new ErrorDTO();
        errorDTO.setMessage(exception.getMessage());
        return new ResponseEntity<>(errorDTO, headers, BAD_REQUEST);
    }

    @ExceptionHandler(value = {Exception.class})
    public ResponseEntity<Object> handleException(Exception exception, NativeWebRequest request) {
        log.error("Handling exception {}", exception.getClass().getCanonicalName(), exception);
        return handleExceptionInternal(exception, exception.getMessage(), new HttpHeaders(), INTERNAL_SERVER_ERROR, request);
    }
}
