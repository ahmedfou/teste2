package com.cacib.trecca.web.rest;

import com.cacib.trecca.domain.Tiers;
import com.cacib.trecca.repository.TiersRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RequiredArgsConstructor
@RestController
@RequestMapping("/api/v1/tiers")
public class TiersResource {

    private final TiersRepository tiersRepository;

    @GetMapping("count")
    public ResponseEntity<Long> count() {
        return ResponseEntity.ok(tiersRepository.count());
    }

    @GetMapping
    public ResponseEntity<List<Tiers>> findAll(Pageable pageable) {
        var tiersPage = tiersRepository.findAll(pageable);
        return ResponseEntity.ok(tiersPage.getContent());
    }

}
