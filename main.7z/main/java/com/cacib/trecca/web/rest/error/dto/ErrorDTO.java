package com.cacib.trecca.web.rest.error.dto;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@java.lang.SuppressWarnings("squid:S1068")
public class ErrorDTO {
    private String message;
}
