package com.cacib.trecca.config;

import java.util.List;

public class Constants {

    private Constants(){}

    public static final String CLASS_PATH = "classpath:";
    public static final String FILE_NAME_DATE_TIME_PATTERN = "yyyyMMdd_HH_mm_ss_SSS";
    public static final String REF_DATE_TIME_PATTERN = "yyyyMMdd";
    public static final String NUMERIC_REGEX = "[0-9]+\\s*";
    public static final String ALPHA_NUMERIC_REGEX = "^[a-zA-Z_][/\\w]*\\s*";
    public static final String NO_REGULAR_ALPHA_NUMERIC_REGEX = "[/\\w]+\\s*";
    public static  final int CRE_HEADER_ID_START_INDEX = 119;
    public static final int CRE_HD_NUMCRE_START_INDEX = 104;
    public static final int CRE_HD_NUMCRE_END_INDEX = 119;
    public static final String CRE_HEADER_ID_TEXT = "HD_XBP                   ";
    public static final int CRE_GPP_HEADER_SIZE = 1096;
    public static final int CRE_GPP_DETAIL_SIZE = 2428;
    public static final String MAPPING_LICREUG_FILE_PATH = "mapping_licreug.json";
    public static final String MAPPING_LNTYPCRE_FILE_PATH = "mapping_lntypcre.json";
    public static final String MAPPING_LNTYPTRANS_FILE_PATH = "mapping_lntyptrans.json";
    public static final String CRE_GPP_DESC_FILE_PATH = "cre_gpp_description.json";
    public static final String RDJ_BI_DESC_FILE_PATH = "rdj_bi_description.json";
    public static final String ME_TDC_DESC_FILE_PATH = "me_tdc_description.json";
    public static final String RDJ_BI_GARNISHES_RULES_FILE_PATH = "rdj_bi_garnishes_rules.json";
    public static final String CRE_GPP_VERIFICATION_FLOW_RULES_FILE_PATH = "cre_gpp_verification_flow_rules.json";
    public static final String ME_TDC_GARNISHES_RULES_FILE_PATH = "me_tdc_garnishes_rules.json";
    public static final String CONTEXT_VAR_STRING_CRE_GPP = "stringCreGPP";
    public static final String CONTEXT_VAR_CRE_HEADER = "header";
    public static final String CONTEXT_VAR_CRE_DETAIL = "detail";

    public static final List<String> ME_DEBIT_VALUES = List.of(
            "PRP_AMT_DEB",
            "PRP_AMT_DEB_BTB"
    );
    public static final List<String> ME_CREDIT_VALUES = List.of(
            "PRP_AMT_CRE",
            "PRP_AMT_CRE_BTB",
            "PRP_AMT_CRE_BRE"
    );
    public static final List<String> BI_DEBIT_VALUES = List.of(
            "PRP_AMT_DEB",
            "PRP_AMT_DEB_ATT",
            "PRP_AMT_DEB_BRE",
            "PRP_AMT_DEB_BTB"
    );
    public static final List<String> BI_CREDIT_VALUES = List.of(
            "PRP_AMT_CRE",
            "PRP_AMT_CRE_ATT",
            "PRP_AMT_CRE_BRE",
            "PRP_AMT_CRE_BTB"
    );
    public static final List<String> BI_CD_OPER_VALUE = List.of(
            "XBPOUT",
            "XBPINC"
    );
    public static final List<String> BI_CD_TYP_FEE_VALUE = List.of(
            "EDC",
            "ADM",
            "CLT"
    );
    public static final List<String> BI_LN_TYP_CPT_VALUE = List.of(
            "LORI",
            "NOSTRI",
            "WASH",
            "AUTRES"
    );
    public static final List<String> ME_LN_TYP_CPT_VALUE = List.of(
            "LORI",
            "NOSTRI"
    );
    public static final String ERROR_FILE_NAME_REGEX = "\\w{17}.\\w{3}.xlsx";
    public static final String CONTEXT_VAR_RULE_RANGE = "RuleRange";
    public static final String CONTEXT_VAR_GPPUTIL_FUNCTION = "GPPUtil";
    public static final String CONTEXT_VAR_MVELUTIL_FUNCTION = "MvelUtil";
    public static final String CONTEXT_VAR_MAPPING_FUNCTION = "mappingFunctions";
    public static final String CONTEXT_VAR_DEBIT_VALUE = "debitValues";
    public static final String CONTEXT_VAR_CREDIT_VALUE = "creditValues";
    public static final String CONTEXT_VAR_LN_TYP_CPT_VALUE = "lnTypCptValues";
    public static final String CONTEXT_VAR_CD_TYP_FEE_VALUE = "cdTypFeeValues";
    public static final String CONTEXT_VAR_CD_OPER_VALUE = "cdOperValues";
    public static final int REFS_ID_TIERS_START_INDEX = 0;
    public static final int REFS_ID_TIERS_END_INDEX = 10;
    public static final int REFS_COD_SOC_CA_START_INDEX = 673;
    public static final int REFS_COD_SOC_CA_END_INDEX = 678;
    public static final int REFS_COD_TIERS_RICOS_SC_START_INDEX = 682;
    public static final int REFS_COD_TIERS_RICOS_SC_END_INDEX = 694;

    /// end add =====>
    
    public static final String CRE_ID_FIELD_NAME = "HD_NUMCRE";
    public static final String RESULT_ME_TDC_LABEL = "ME_TDC";
    public static final String RESULT_RDJ_BI_LABEL = "RDJ_BI";
    public static final String RESULT_ERROR_LABEL = "ERROR";
    public static final String LN_TYP_CPT = "LN_TYP_CPT";
    public static final String AMOUNT_TYPE = "AMOUNT_TYP";
    public static final String BOOK_MARGIN_MNT = "BOOK_MARGIN_MNT";
    public static final String CD_OPER = "CD_OPER";
    public static final String CD_TYP_FEE = "CD_TYP_FEE";
    public static final String HD_ENTITY = "HD_ENTITY";
    public static final String HD_ENTITY_TRECCA = "00018";
    
    public static final String DATE_TIME_PATTERN = "yyyy-MM-dd HH:mm:ss";
    public static final String CONTEXT_VAR_FUNCTION = "functions";
}
