package com.cacib.trecca.config;

import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.springframework.boot.autoconfigure.kafka.KafkaProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.cacib.trecca.util.KafkaUtil;

import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@Configuration
public class KafkaConsumerConfig {

	private final KafkaProperties kafkaProperties;

	@Bean
	public KafkaConsumer<String, String> oilConsumer() {
		return KafkaUtil.createConsumer(kafkaProperties);
	}
}
