package com.cacib.trecca.config;

import lombok.Getter;
import lombok.Setter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@Getter
@Setter
@Component
@ConfigurationProperties(prefix = "cacib.trecca")
public class ApplicationProperties {

    private final Kafka kafka = new Kafka();
    private final Queue queue = new Queue();
    private final Storage storage = new Storage();

    private final Mail mail = new Mail();
    private final Referential referential = new Referential();
    private final Export export = new Export();
    private final List<String> debitValues = new ArrayList<>();
    private final List<String> creditValues = new ArrayList<>();
    private final List<String> lnTypCptValues = new ArrayList<>();
    private final List<String> cdTypFeeValues = new ArrayList<>();
    private final List<String> cdOperValues = new ArrayList<>();
    private Boolean sendTdc = Boolean.FALSE;
    private Boolean sendBi = Boolean.FALSE;

    @Getter
    @Setter
    public static class Mail {
        private String from;
        private String[] to;
        private String[] cc;
    }

    @Getter
    @Setter
    public static class Kafka {
        private final Topic topic = new Topic();
        private String keystoreLocation;
        private int pollDuration;
        
        @Getter
        @Setter
        // en total 9 topics
        //reprocess_gpp, reprocess_rdjbicasa, reprocess_sgotdc, reject_rdjbicasa, reject_sgotdc, reject_gpp, archive_rdjbicasa, archive_sgotdc, archive_gpp
        public static class Topic {
            private String cregpp;
            private String reprocessGpp;
            private String rdjbicasa;
            private String sgotdc;
            private String rejectGpp;
            private String rejectRdjbicasa;
            private String rejectSgotdc;
            private String reprocessSgotdc;
            private String archiveGpp;
            private String archiveSgotdc;
            private String archiveRdjbicasa;
            private String reprocessRdjbicasa;
        }
    }

    @Getter
    @Setter
    public static class Storage {
    	
    	private final Bucket bucket= new Bucket();
        private String accessKey;
        private String secretKey;
        private String region;
        private String url;
        
        @Getter
        @Setter
        public static class Bucket {
        	private String importName;
        	private String archiveImportName;
        	private String exportName;
        	private String archiveExportName;
        }
    }

    @Getter
    @Setter
    public static class Queue {
        private String name;
    }
    
    @Getter
    @Setter
    public static class Referential {
    	private final Tiers tiers = new Tiers();
    	
    	@Getter
    	@Setter
    	public static class Tiers {
    		private String path;
    		private String fileNameTemplate;
            /**
             * File name regex expression pattern
             */
    		private String regexp;
    		private String archiveCron;
    	}
    }
    
    @Getter
    @Setter
    public static class Export {
    	private String rdjBiPath;
    }
}
