package com.cacib.trecca.config;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import software.amazon.awssdk.auth.credentials.AwsBasicCredentials;
import software.amazon.awssdk.auth.credentials.StaticCredentialsProvider;
import software.amazon.awssdk.regions.Region;
import software.amazon.awssdk.services.s3.S3Client;

import java.net.URI;
import java.net.URISyntaxException;

@Slf4j
@RequiredArgsConstructor
@Configuration
public class StorageConfiguration {

    @Bean
    public S3Client s3Client(final ApplicationProperties properties) throws URISyntaxException {
        // @formatter:off
        log.info("Instantiating S3 client for {}", properties.getStorage().getUrl());
        var credentialsProvider = StaticCredentialsProvider
                .create(AwsBasicCredentials.create(properties.getStorage().getAccessKey(), properties.getStorage().getSecretKey()));

        return S3Client.builder()
                .region(Region.of(properties.getStorage().getRegion()))
                .credentialsProvider(credentialsProvider)
                .forcePathStyle(true)
                .endpointOverride(new URI(properties.getStorage().getUrl()))
                .build();
        // @formatter:on
    }
}
