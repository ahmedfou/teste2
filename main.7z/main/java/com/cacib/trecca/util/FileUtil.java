package com.cacib.trecca.util;

import com.cacib.trecca.config.Constants;
import com.cacib.trecca.domain.Tiers;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.io.Resource;
import org.springframework.web.multipart.MultipartFile;

import java.io.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.regex.Pattern;

import static com.cacib.trecca.config.Constants.*;

@Slf4j
public final class FileUtil {

    private FileUtil() {
    }

    public static boolean isMultipartFileValid(MultipartFile file) {
        if (file == null) {
            return false;
        }
        var contentType = file.getContentType();
        return (contentType != null) && contentType.contains("text/plain") && !file.isEmpty();
    }

    public static String generateUniqueFileName(String prefix, String extension) {
        return prefix + DateTimeFormatter.ofPattern(FILE_NAME_DATE_TIME_PATTERN).format(LocalDateTime.now()) + "." + extension;
    }

    public static Tiers mapLineToTiers(String line) {
        if (line == null) return null;
        var tiers = new Tiers();
        tiers.setIdTiers(line.substring(REFS_ID_TIERS_START_INDEX, REFS_ID_TIERS_END_INDEX));
        tiers.setCodSocCa(line.substring(REFS_COD_SOC_CA_START_INDEX, REFS_COD_SOC_CA_END_INDEX));
        tiers.setCodTiersRicosSc(line.substring(REFS_COD_TIERS_RICOS_SC_START_INDEX, REFS_COD_TIERS_RICOS_SC_END_INDEX));
        return tiers;
    }

    public static <T> T readJsonFile(Resource resource, Class<T> classType) {
        var objectMapper = new ObjectMapper();
        try {
            return objectMapper.readerFor(classType).readValue(resource.getInputStream());
        } catch (IOException e) {
            log.error("===> Error while reading file " + resource.getFilename(), e);
            return null;
        }
    }

    public static <T> List<T> readJsonArrayFile(Resource resource, Class<T> tClass) {
        var objectMapper = new ObjectMapper();
        var lType = objectMapper.getTypeFactory().constructCollectionType(List.class, tClass);
        try {
            return objectMapper.readerFor(lType).readValue(resource.getInputStream());
        } catch (IOException e) {
            log.error("===> Error while reading file " + resource.getFilename(), e);
            return Collections.emptyList();
        }
    }

    public static List<String> getErrorFileNameFromString(String chaine) {
        var result = new ArrayList<String>();
        var pattern = Pattern.compile(Constants.ERROR_FILE_NAME_REGEX);
        var matcher = pattern.matcher(chaine);
        while (matcher.find()) {
            result.add(matcher.group());
        }
        return result;
    }


}