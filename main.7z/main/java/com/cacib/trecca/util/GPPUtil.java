package com.cacib.trecca.util;

import com.cacib.trecca.config.Constants;
import com.cacib.trecca.model.CreGPPDescription;
import com.cacib.trecca.model.CreGPPFlux;
import com.cacib.trecca.model.Field;
import com.cacib.trecca.rule.GarnishesRule;
import com.cacib.trecca.rule.Rule;
import com.cacib.trecca.types.PadDirection;
import com.cacib.trecca.types.RuleRange;
import org.apache.commons.lang3.StringUtils;
import org.mvel2.MVEL;
import org.springframework.beans.BeanUtils;
import org.springframework.core.io.Resource;
import org.springframework.data.util.Pair;

import java.util.*;
import java.util.stream.Collectors;

public final class GPPUtil {
    private GPPUtil(){}
    
    // Use in the MVEL to validate the structure of the CRE
    public static boolean isValidCreGPP(String creStr) {
        if(creStr == null || creStr.isBlank() || creStr.lines().count() != 3) return false;
        // Check the sizes of the lines
        var sizeCheck = creStr.lines().map(GPPUtil::isCreGPPSizeCorrect).reduce(Boolean::logicalAnd).orElse(false);
        // check that all the cre has the same HD_NUMCRE
        var hdNumCre = GPPUtil.getCreHdNumcre(creStr.lines().findFirst().orElse(""));
        var hdNumCreCheck = creStr.lines().map(GPPUtil::getCreHdNumcre).allMatch(cre -> cre != null && cre.equals(hdNumCre));
        //count the number of header line
        var countHeaderLine = creStr.lines().filter(GPPUtil::isHeaderCreGPP).count();
        // Count the number of details line
        var countDetaiLines = creStr.lines().filter(GPPUtil::isDetailCreGPP).count();
        // Return result of the tests of the validity of the cre
        return sizeCheck && hdNumCreCheck && countHeaderLine == 1 && countDetaiLines == 2;
    }

    public static boolean isCreGPPSizeCorrect(String creGpp){
        return creGpp != null && Arrays.asList(Constants.CRE_GPP_HEADER_SIZE, Constants.CRE_GPP_DETAIL_SIZE).contains(creGpp.length());
    }

    public static boolean isHeaderCreGPP(String creGPP){
        return creGPP != null && creGPP.length() == Constants.CRE_GPP_HEADER_SIZE && creGPP.startsWith(Constants.CRE_HEADER_ID_TEXT, Constants.CRE_HEADER_ID_START_INDEX);
    }

    public static boolean isDetailCreGPP(String creGPP){
        return creGPP != null && creGPP.length() == Constants.CRE_GPP_DETAIL_SIZE && !creGPP.startsWith(Constants.CRE_HEADER_ID_TEXT, Constants.CRE_HEADER_ID_START_INDEX);
    }

    public static String getCreHdNumcre(String creGpp){
        if(creGpp == null || creGpp.length() < Constants.CRE_HD_NUMCRE_END_INDEX) return null;
        return creGpp.substring(Constants.CRE_HD_NUMCRE_START_INDEX, Constants.CRE_HD_NUMCRE_END_INDEX);
    }
    
    public static Map<String, Field> mapCreDescriptionToValue(String creValue, List<Field> creDescription){
        Map<String, Field> result = new HashMap<>();
        int startIndex;
        int endIndex;
        for(var descField: creDescription){
            var field = new Field();
            BeanUtils.copyProperties(descField, field);

            startIndex = field.getPosition() - 1;
            endIndex = startIndex + field.getLength();

            field.setValue(creValue.substring(startIndex, endIndex));
            result.put(field.getTechnicalName(), field);
        }
        return result;
    }

    public static Pair<CreGPPFlux, CreGPPFlux> transformStringIntoCreGPPFlux(String stringCre, Resource resource){
        // Outputs
        var fluxOne = new CreGPPFlux();
        var fluxTwo = new CreGPPFlux();
        // Process Inputs
        var creGPPDescription = FileUtil.readJsonFile(resource, CreGPPDescription.class);
        var headerStr = stringCre.lines().filter(GPPUtil::isHeaderCreGPP).findFirst().orElse("");
        var hdNumCre = GPPUtil.getCreHdNumcre(headerStr);
        var detailList = stringCre.lines().filter(GPPUtil::isDetailCreGPP).toList();
        // Prepares results
        var index = 0;
        for(var detailStr: detailList){
            var fluxToWorkOn = index == 0 ? fluxOne : fluxTwo;
            // Header settings
            fluxToWorkOn.setHdNumcre(hdNumCre);
            fluxToWorkOn.setInputHeader(headerStr);
            fluxToWorkOn.setHeader(GPPUtil.mapCreDescriptionToValue(headerStr, creGPPDescription.getHeaderDescription()));
            // Details settings
            fluxToWorkOn.setInputDetail(detailStr);
            fluxToWorkOn.setDetail(GPPUtil.mapCreDescriptionToValue(detailStr, creGPPDescription.getDetailDescription()));
            index++;
        }
        // Return results
        return Pair.of(fluxOne, fluxTwo);
    }

    public static String executeGarnishesRule(GarnishesRule garnRules, RuleRange ruleRange, Map<Object, Object> contextParams, List<Field> outputDescription){
        List<Rule> rules = new ArrayList<>();
        for (var garRule : garnRules.getRules()) {
            var rule = new Rule();
            BeanUtils.copyProperties(garRule, rule);
            rule.setCompileExpression(MVEL.compileExpression(rule.getExpression()));
            rules.add(rule);
        }
        // Execute the garnishes rule and map name of the field with the value
        var garnishesValues =  rules.stream()
            .filter(rule -> rule.getRuleRange() == ruleRange || rule.getRuleRange() == RuleRange.COMMON)
            .collect(Collectors.toMap(Rule::getName, rule -> MVEL.executeExpression(rule.getCompileExpression(), contextParams, String.class)));
        // Ordered output description fields and pad the value with the completion character
        List<Field> fields = new ArrayList<>();
        var orderedOutDesc = outputDescription.stream().sorted(Comparator.comparingInt(Field::getPosition)).collect(Collectors.toList());
        for(var descField: orderedOutDesc){
            var field = new Field();
            BeanUtils.copyProperties(descField, field);
            var currentValue = garnishesValues.get(field.getTechnicalName());
            var taille = field.getLength();
            var padChar = field.getPadChar();
            if(currentValue != null) {
                var calValue = (field.getPadDirection().equals(PadDirection.LEFT)) ? StringUtils.leftPad(currentValue, taille, padChar) : StringUtils.rightPad(currentValue, taille, padChar);
                field.setValue(calValue);
                fields.add(field);
            }
        }
        // Concat and return the result
        return fields.stream().map(Field::getValue).reduce(String::concat).orElse("").concat("\n");
    }

    


}
