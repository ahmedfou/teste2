package com.cacib.trecca.util;

import com.cacib.trecca.config.Constants;
import com.cacib.trecca.web.rest.error.TreccaException;
import org.apache.commons.lang3.StringUtils;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

public final class MvelUtil {
    
    private MvelUtil(){}
    
    public static  <T>boolean in(T value, List<T> values) {
        return value != null && values.contains(value);
    }

    public static  String formatDate(String inputDate, String inputFormat, String outputFormat) {
        Date date;
        try {
            date = new SimpleDateFormat(inputFormat).parse(inputDate);
            return new SimpleDateFormat(outputFormat).format(date);
        } catch (ParseException e) {
            throw new TreccaException("Invalid date parsing format " + outputFormat + " for the date "+ inputDate);
        }
    }

    public static  String leftPad(String value, int size, char padChar) {
        return StringUtils.leftPad(value, size, padChar);
    }

    public static  String rightPad(String value, int size, char padChar) {
        return StringUtils.rightPad(value, size, padChar);
    }

    public static  String splitRegex(String params, String regex){
        return Arrays.stream(params.trim().split(regex)).reduce(String::concat).orElse("");
    }

    public static  boolean isNumeric(String value, int size){
        return value != null && value.matches(Constants.NUMERIC_REGEX) && value.length() == size;
    }

    public static  boolean isAlphaNumeric(String value, int size){
        return value != null && value.matches(Constants.ALPHA_NUMERIC_REGEX) && value.length() == size;
    }

    public static  boolean isNoRegularAlphaNumeric(String value, int size){
        return value != null && value.matches(Constants.NO_REGULAR_ALPHA_NUMERIC_REGEX) && value.length() == size;
    }

    public static  boolean isValidDate(String date, String dateFormat){
        if(date == null || dateFormat == null || dateFormat.length() != date.length()) return false;
        var sdf = new SimpleDateFormat(dateFormat);
        sdf.setLenient(false);
        try {
            sdf.parse(date);
            return true;
        } catch (ParseException e) {
            return false;
        }
    }

    public static  boolean isMatchSize(String value, int size){
        return value != null && value.length() == size;
    }


    
    
    
}
