package com.cacib.trecca.util;

import org.apache.commons.lang3.ObjectUtils;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.springframework.boot.autoconfigure.kafka.KafkaProperties;

import java.util.HashMap;
import java.util.Map;

import static org.apache.kafka.clients.CommonClientConfigs.SECURITY_PROTOCOL_CONFIG;
import static org.apache.kafka.common.config.SaslConfigs.SASL_JAAS_CONFIG;
import static org.apache.kafka.common.config.SaslConfigs.SASL_MECHANISM;
import static org.apache.kafka.common.config.SslConfigs.SSL_TRUSTSTORE_LOCATION_CONFIG;

public class KafkaUtil {
	private KafkaUtil() {
	}

	public static <K, V> KafkaConsumer<K, V> createConsumer(KafkaProperties kafkaProperties) {
		return new KafkaConsumer<>(getConsumerProperties(kafkaProperties));
	}

	private static Map<String, Object> getConsumerProperties(KafkaProperties kafkaProperties) {
		var config = new HashMap<String, Object>();
		if(ObjectUtils.isNotEmpty(kafkaProperties.getConsumer().getProperties().get(SSL_TRUSTSTORE_LOCATION_CONFIG))) {
			config.put(SSL_TRUSTSTORE_LOCATION_CONFIG,
					kafkaProperties.getConsumer().getProperties().get(SSL_TRUSTSTORE_LOCATION_CONFIG));
		}
		
		if (ObjectUtils.isNotEmpty(kafkaProperties.getConsumer().getSecurity().getProtocol())) {
			config.put(SECURITY_PROTOCOL_CONFIG, kafkaProperties.getConsumer().getSecurity().getProtocol());
		}

		if (ObjectUtils.isNotEmpty(kafkaProperties.getConsumer().getProperties().get(SASL_MECHANISM))) {
			config.put(SASL_MECHANISM, kafkaProperties.getConsumer().getProperties().get(SASL_MECHANISM));
		}

		if (ObjectUtils.isNotEmpty(kafkaProperties.getConsumer().getProperties().get(SASL_JAAS_CONFIG))) {
			config.put(SASL_JAAS_CONFIG, kafkaProperties.getConsumer().getProperties().get(SASL_JAAS_CONFIG));
		}

		config.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, kafkaProperties.getConsumer().getBootstrapServers());
		config.put(ConsumerConfig.GROUP_ID_CONFIG, kafkaProperties.getConsumer().getGroupId());
		config.put(ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG, kafkaProperties.getConsumer().getEnableAutoCommit());
		config.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, kafkaProperties.getConsumer().getAutoOffsetReset());
		config.put(ConsumerConfig.MAX_POLL_RECORDS_CONFIG, kafkaProperties.getConsumer().getMaxPollRecords());

		config.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, kafkaProperties.getConsumer().getKeyDeserializer());
		config.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG,
				kafkaProperties.getConsumer().getValueDeserializer());

		return config;
	}
}
