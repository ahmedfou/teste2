package com.cacib.trecca.util;

import com.cacib.trecca.rule.ValidationResult;
import lombok.extern.slf4j.Slf4j;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.HorizontalAlignment;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.VerticalAlignment;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.IntStream;


@Slf4j
public final class ErrorCsvUtil {
    private ErrorCsvUtil(){}
    
    public static  List<String[]> sizeCheckContent(String creStr){
        var result = new ArrayList<String[]>();
        //This is the Header for the Excel error file
        result.add(new String[]{"Num", "Champ", "Message", "Valeur du CRE"});
        if(creStr == null || creStr.isBlank()){
            result.add(new String[]{"1", "CRE", "La structure du CRE devrait contenir 3 lignes un HEADER et 2 details. Pour l'instant c'est une chaine vide", creStr});
            return result;
        }
        if(creStr.lines().count() != 3) {
            result.add(new String[]{"1", "CRE", "La structure du CRE est incorrect. Il contient " + creStr.lines().count() + " ligne(s)", creStr});
            return result;
        }
        // Check the sizes of the lines
        var sizeCheck = creStr.lines().map(GPPUtil::isCreGPPSizeCorrect).reduce(Boolean::logicalAnd).orElse(false);
        // check that all the cre has the same HD_NUMCRE
        var hdNumCre = GPPUtil.getCreHdNumcre(creStr.lines().findFirst().orElse(""));
        var hdNumCreCheck = creStr.lines().map(GPPUtil::getCreHdNumcre).allMatch(cre -> cre != null && cre.equals(hdNumCre));
        //count the number of header line
        var countHeaderLine = creStr.lines().filter(GPPUtil::isHeaderCreGPP).count();
        // Count the number of details line
        var countDetaiLines = creStr.lines().filter(GPPUtil::isDetailCreGPP).count();
        // Return result of the tests of the validity of the cre

        var index = 1;
        if(Boolean.FALSE.equals(sizeCheck)) {
            result.add(new String[]{"" + index++, "CRE", "La taille du HEADER doit etre de 2428 et celle des DETAILS est de 1096 (Voir la SFD)", creStr});
        }
        if(!hdNumCreCheck) {
            result.add(new String[]{"" + index++, "CRE", "Le champ HD_NUMCRE n'est pas le meme pour le header et les details (" + hdNumCre + ").", creStr});
        }
        if(countHeaderLine != 1) {
            result.add(new String[]{"" + index++, "HEADER", "Le CRE ne possede pas de header valide. Verifier la position du champ HD_NUMCRE", creStr});
        }
        if(countDetaiLines != 2) {
            result.add(new String[]{"" + index, "DETAIL", "Le CRE ne possede pas de details valide. Verifier la position du champ HD_NUMCRE", creStr});
        }
        return result;
    }
    
    
    public static List<String[]> validationCheckContent(ValidationResult validationResult){
        var index = new AtomicInteger(1);
        var result = new ArrayList<String[]>();
        result.add(new String[]{"Num", "Identification du CRE", "Non du champ", "Valeur du champ", "Position",  "Message"});
        validationResult.getHeaderErrorRules().forEach((rule, field) -> {
            var position = String.valueOf(field.getPosition());
            result.add(new String[]{String.valueOf(index.getAndIncrement()), "Header (" + validationResult.getNumCre() + ")", field.getTechnicalName(), field.getValue(), position, rule.getMessage()});
        });
        validationResult.getDetailOneErrorRules().forEach((rule, field) -> {
            var position = String.valueOf(field.getPosition());
            result.add(new String[]{String.valueOf(index.getAndIncrement()), "Detail #1 (" + validationResult.getNumCre() + ")", field.getTechnicalName(), field.getValue(), position, rule.getMessage()});
        });
        validationResult.getDetailTwoErrorRules().forEach((rule, field) -> {
            var position = String.valueOf(field.getPosition());
            result.add(new String[]{String.valueOf(index.getAndIncrement()), "Detail #2 (" + validationResult.getNumCre() + ")", field.getTechnicalName(), field.getValue(), position, rule.getMessage()});
        });
        return result;
    }
    
    public static boolean generateErrorExcelFile(List<String[]> content, String filePath){
        try(var workbook = new XSSFWorkbook()) {
            // Create the Workbook
            var sheet = workbook.createSheet("Rejets");
            // Styles
            var headerStyle = workbook.createCellStyle();
            var cellStyle = workbook.createCellStyle();
            headerStyle.setFillForegroundColor(IndexedColors.LIGHT_BLUE.getIndex());
            headerStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);
            headerStyle.setWrapText(true);
            headerStyle.setVerticalAlignment(VerticalAlignment.CENTER);
            headerStyle.setAlignment(HorizontalAlignment.CENTER);
            headerStyle.setWrapText(true);
            cellStyle.setWrapText(true);
            cellStyle.setVerticalAlignment(VerticalAlignment.CENTER);
            // Font Styles
            var font = workbook.createFont();
            font.setFontName("Arial");
            font.setFontHeightInPoints((short) 10);
            font.setBold(true);
            font.setItalic(true);
            font.setColor(IndexedColors.WHITE.getIndex());
            headerStyle.setFont(font);
            // Write Data in the Workbook
            var  rowNumber = 0;
            for(var contentEntry: content){
                var row = sheet.createRow(rowNumber++);
                if(rowNumber == 1){
                    row.setHeight((short)500);
                }
                var cellNumber = 0;
                for(String cellContent : contentEntry){
                    var cell = row.createCell(cellNumber++);
                    cell.setCellValue(cellContent);
                    if(rowNumber == 1){
                        cell.setCellStyle(headerStyle);
                    } else {
                        cell.setCellStyle(cellStyle);
                    }
                }
            }
            // Auto-size the content
            IntStream.range(0, content.get(0).length).forEach(sheet::autoSizeColumn);
            // Create the workbook in a file
            var outputStream = new FileOutputStream(filePath);
            workbook.write(outputStream);
            outputStream.close();
            return true;
        } catch (Exception e) {
            log.info("Error while generating the Excel file", e);
            return false;
        }
    }
    
}
