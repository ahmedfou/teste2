package com.cacib.trecca.storage.model;

import lombok.Data;

@Data
public class FsFile {
	private String name;
	private byte[] content;
}
