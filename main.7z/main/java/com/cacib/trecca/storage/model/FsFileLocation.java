package com.cacib.trecca.storage.model;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Data
public class FsFileLocation {

	@NotNull
	@NotBlank
	private String bucket;

	@NotNull
	@NotBlank
	private String directory;

	@NotNull
	@NotBlank
	private String name;
}
