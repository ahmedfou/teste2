package com.cacib.trecca.storage.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.net.URI;
import java.time.Instant;

@NoArgsConstructor
@AllArgsConstructor
@Data
public class FsFileDetail {
	private String bucket;
	private String name;
	private String path;
	private String directory;
	private URI uri;
	private long size;
	private Instant creationDate;
	private Instant modificationDate;
}
