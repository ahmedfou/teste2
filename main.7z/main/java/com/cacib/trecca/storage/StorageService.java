package com.cacib.trecca.storage;

import com.cacib.trecca.storage.model.FsFileDetail;
import com.cacib.trecca.storage.model.FsFileLocation;
import com.cacib.trecca.storage.request.OperationResult;
import com.cacib.trecca.storage.util.FsUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import software.amazon.awssdk.core.sync.RequestBody;
import software.amazon.awssdk.services.s3.S3Client;
import software.amazon.awssdk.services.s3.model.*;

import java.io.File;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.List;

@Slf4j
@RequiredArgsConstructor
@Component
public class StorageService {
    private final S3Client s3Client;

    public OperationResult<List<FsFileDetail>> listFiles(String storage, String prefix, int maxKeys) {
        var result = FsUtil.<List<FsFileDetail>>defaultOperationResult();
        var allFiles = new ArrayList<FsFileDetail>();
        var request = ListObjectsV2Request.builder().bucket(storage).prefix(prefix).maxKeys(maxKeys).build();

        try {
            var response = s3Client.listObjectsV2Paginator(request);

            for (var page : response) {
                var files = page.contents().stream().map(object -> {
                    var fsFileDetail = new FsFileDetail();
                    fsFileDetail.setBucket(storage);
                    fsFileDetail.setPath(object.key());
                    fsFileDetail.setDirectory(FsUtil.getParentDirectoryName(object.key()));
                    fsFileDetail.setName(FsUtil.getObjectName(object.key()));
                    fsFileDetail.setCreationDate(object.lastModified());
                    fsFileDetail.setModificationDate(object.lastModified());
                    fsFileDetail.setSize(object.size());
                    fsFileDetail.setUri(FsUtil.getUri("", storage, object.key()));
                    return fsFileDetail;
                }).toList();

                allFiles.addAll(files);
            }

            result.setResult(allFiles);
        } catch (Exception exception) {
            log.error("An exception has occurred", exception);
            result.setSuccess(false);
            result.setMessages(List.of(exception.getMessage()));
        }

        return result;
    }

    public OperationResult<Long> downloadTo(FsFileLocation location, String destinationDir) {
        log.info("About to download file. Storage: {}, directory: {}, name: {} destination directory {}", location.getBucket(),
                location.getDirectory(), location.getName(), destinationDir);
        var result = FsUtil.<Long>defaultOperationResult();

        try {
            var path = FsUtil.buildAbsolutePath(location.getDirectory(), location.getName());
            var request = GetObjectRequest.builder().bucket(location.getBucket()).key(path).build();
            var response = s3Client.getObject(request);
            long transferredBytes = response.transferTo(new FileOutputStream(new File(destinationDir, location.getName())));
            log.info("Transferred bytes is {}", transferredBytes);
            result.setResult(transferredBytes);
        } catch (Exception exception) {
            result.setResult(0L);
            log.error("An error has occurred", exception);
            result.setSuccess(false);
            result.setMessages(List.of(exception.getMessage()));
        }

        return result;
    }

    public OperationResult<Void> uploadFile(FsFileLocation location, File file) {
        var result = FsUtil.<Void>defaultOperationResult();
        try {
            var request = PutObjectRequest.builder().bucket(location.getBucket())
                    .key(FsUtil.buildAbsolutePath(location.getDirectory(), location.getName())).build();
            var response = s3Client.putObject(request, RequestBody.fromFile(file));

            log.info("File {} uploaded with status code {}",
                    FsUtil.buildAbsolutePath(location.getDirectory(), location.getName()),
                    response.sdkHttpResponse().statusCode());
        } catch (Exception exception) {
            log.error("An error occurred while uploading file {}", location.getName(), exception);
            result.setSuccess(false);
            result.setMessages(List.of(exception.getMessage()));
        }

        return result;
    }

    public OperationResult<Void> deleteFile(String bucket, String prefix) {
        var result = FsUtil.<Void>defaultOperationResult();

        try {
            var request = DeleteObjectRequest.builder().bucket(bucket)
                    .key(prefix).build();
            var response = s3Client.deleteObject(request);

            log.info("File {} deleted {}", bucket + "/" + prefix, response.toString());
        } catch (Exception exception) {
            result.setSuccess(false);
            result.setMessages(List.of(exception.getMessage()));
        }
        return result;
    }

    public OperationResult<Void> copyFile(String sourceBucket, String sourcePrefix, String targetBucket, String targetPrefix) {
        var result = FsUtil.<Void>defaultOperationResult();
        var request = CopyObjectRequest.builder().sourceBucket(sourceBucket)
                .sourceKey(sourcePrefix)
                .destinationBucket(targetBucket)
                .destinationKey(targetPrefix).build();
        try {
            var response = s3Client.copyObject(request);
            log.info("File {} copied to {}: {}", sourceBucket + "/" + sourcePrefix,
                    targetBucket + "/" + targetPrefix, response.copyObjectResult().toString());
        } catch (Exception exception) {
            result.setSuccess(false);
            result.setMessages(List.of(exception.getMessage()));
        }

        return result;
    }

    public OperationResult<Void> moveFile(String sourceBucket, String sourcePrefix, String targetBucket, String targetPrefix) {
        var result = copyFile(sourceBucket, sourcePrefix, targetBucket, targetPrefix);
        if (!result.isSuccess()) {
            return result;
        }

        return deleteFile(sourceBucket, sourcePrefix);
    }
}
