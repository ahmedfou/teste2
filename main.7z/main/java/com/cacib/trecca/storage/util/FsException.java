package com.cacib.trecca.storage.util;

public class FsException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 2323688484368171265L;

}
