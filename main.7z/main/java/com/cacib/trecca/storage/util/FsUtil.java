package com.cacib.trecca.storage.util;

import com.cacib.trecca.storage.request.OperationResult;
import lombok.extern.slf4j.Slf4j;

import java.net.URI;
import java.net.URISyntaxException;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.Objects;

/**
 * Utility class for File Storage library
 * 
 * @author ut2nyq
 *
 */
@Slf4j
public final class FsUtil {

	private static final String PATH_SEPARATOR = "/";

	private FsUtil() {
	}

	/**
	 * Get object name from path
	 * 
	 * @param path path name
	 * @return object name
	 */
	public static String getObjectName(String path) {
		FsUtil.checkNullPath(path);

		if (FsUtil.isDirectory(path)) {
			path = path.substring(0, path.length() - 1);
		}

		FsUtil.checkNullPath(path);

		var lastIndexOfSeparator = path.lastIndexOf(PATH_SEPARATOR);

		if (lastIndexOfSeparator < 0) {
			return path;
		}

		return path.substring(lastIndexOfSeparator + 1);
	}

	/**
	 * Get parent directory
	 * 
	 * @param path path name
	 * @return parent directory
	 */
	public static String getParentDirectoryName(String path) {
		FsUtil.checkNullPath(path);

		if (FsUtil.isRootDirectory(path)) {
			return "";
		}

		if (FsUtil.isDirectory(path)) {

			path = path.substring(0, path.length() - 1);
		}

		var lastIndexOfSeparator = path.lastIndexOf(PATH_SEPARATOR);

		return path.substring(0, lastIndexOfSeparator + 1);
	}

	/**
	 * Get URI
	 * 
	 * @param baseUrl base URL
	 * @param storage storage name
	 * @param path    path name
	 * @return URI The URI of the file <code>path</code> or <code>null</code> if the
	 *         URI cannot be built.
	 */
	public static URI getUri(String baseUrl, String storage, String path) {
		URI uri = null;
		try {
			var fullPath = baseUrl + PATH_SEPARATOR + storage + PATH_SEPARATOR + path;
			var encodedPath = URLEncoder.encode(fullPath, StandardCharsets.UTF_8);
			log.info("Encoded path is {}", encodedPath);
			uri = new URI(encodedPath);
		} catch (URISyntaxException exception) {
			log.warn("Unable to build URI for {} - {} - {}", baseUrl, storage, path, exception);
		}

		return uri;
	}

	/**
	 * Build absolute path
	 * 
	 * @param directory directory name
	 * @param name      file name
	 * @return absolute path
	 */
	public static String buildAbsolutePath(String directory, String name) {
		return (directory == null || directory.isBlank()) ? name : (directory + PATH_SEPARATOR + name);
	}

	/**
	 * Default operation result
	 * 
	 * @return default operation result
	 */
	public static <T> OperationResult<T> defaultOperationResult() {
		var result = new OperationResult<T>();
		result.setSuccess(true);
		result.setResult(null);
		result.setMessages(null);

		return result;
	}

	/**
	 * Check whether the path <code>path</code> is directory or not
	 * 
	 * @param path path name
	 * @return <code>true</code> if <code>path</code> is a directory and
	 *         <code>false</code> if not
	 */
	private static boolean isDirectory(String path) {
		return path.endsWith(PATH_SEPARATOR);
	}

	/**
	 * Check whether the path <code>path</code> is a root directory or not
	 * 
	 * @param path path name
	 * @return <code>true</code> if <code>path</code> is a root directory and
	 *         <code>false</code> if not
	 */
	private static boolean isRootDirectory(String path) {
		FsUtil.checkNullPath(path);

		return PATH_SEPARATOR.equals(path);
	}

	/**
	 * Check if the path path <code>path</code> is null or empty
	 */
	private static void checkNullPath(String path) {
		if (Objects.isNull(path)) {
			throw new IllegalArgumentException("Le chemin du fichier ne doit pas etre null");
		}

		if (path.isBlank()) {
			throw new IllegalArgumentException("Le chemin " + path + " ne doit pas etre vide");
		}
	}
}
