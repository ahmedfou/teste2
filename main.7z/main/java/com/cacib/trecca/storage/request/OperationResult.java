package com.cacib.trecca.storage.request;

import lombok.Data;

import java.util.List;

@Data
@java.lang.SuppressWarnings("squid:S1068")
public class OperationResult<T> {
	private T result;
	private boolean success;
	private List<String> messages;
}
