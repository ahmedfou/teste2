package com.cacib.trecca.rule;

import com.cacib.trecca.model.Field;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import java.util.Map;

@Data
@Slf4j
@NoArgsConstructor
@AllArgsConstructor
public class ValidationResult {
    private String numCre;
    private boolean status;
    private Map<Rule, Field> headerErrorRules;
    private Map<Rule, Field> detailOneErrorRules;
    private Map<Rule, Field> detailTwoErrorRules;
}
