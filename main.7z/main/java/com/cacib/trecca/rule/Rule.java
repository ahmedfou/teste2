package com.cacib.trecca.rule;

import com.cacib.trecca.types.RuleRange;
import lombok.Data;

import java.io.Serializable;

@Data
public class Rule {
    private String name;
    private String message;
    private String expression;
    private RuleRange ruleRange;
    private Serializable compileExpression;
}
