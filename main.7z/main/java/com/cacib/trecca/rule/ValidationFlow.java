package com.cacib.trecca.rule;

import com.cacib.trecca.config.Constants;
import com.cacib.trecca.core.MappingFunctions;
import com.cacib.trecca.model.CreGPPFlux;
import com.cacib.trecca.types.RuleRange;
import com.cacib.trecca.util.GPPUtil;
import com.cacib.trecca.util.MvelUtil;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.mvel2.MVEL;
import org.springframework.beans.BeanUtils;
import org.springframework.data.util.Pair;

import java.util.*;
import java.util.stream.Collectors;

@Data
@Slf4j
@NoArgsConstructor
public class ValidationFlow {
    private Rule sizeCheck;
    private ValidationRule validationCheck;
    private Rule exceptionCheck;
    private Rule rdjbiCheck;
    private Rule metdcCheck;
    private List<Rule> mappingCheck;
    private Rule referentialCheck;
    
    
    public boolean executeSizeCheck(String creStr){
        if(this.sizeCheck.getCompileExpression() == null){
            //SizeCheck
            var newSizeCheck = new Rule();
            BeanUtils.copyProperties(this.getSizeCheck(), newSizeCheck);
            newSizeCheck.setCompileExpression(MVEL.compileExpression(newSizeCheck.getExpression()));
            this.setSizeCheck(newSizeCheck);
        }
        var checkParams = new HashMap<String, Object>();
        checkParams.put(Constants.CONTEXT_VAR_STRING_CRE_GPP, creStr);
        checkParams.put(Constants.CONTEXT_VAR_GPPUTIL_FUNCTION, GPPUtil.class);
        return MVEL.executeExpression(this.sizeCheck.getCompileExpression(), checkParams, boolean.class);
    }
    
    public ValidationResult executeValidationCheck(Pair<CreGPPFlux, CreGPPFlux> gppFlux){
        if(!this.validationCheck.getHeaderRules().isEmpty() && this.validationCheck.getHeaderRules().get(0).getCompileExpression() == null){
            var newValidationCheck = new ValidationRule();
            var headerRules = new ArrayList<Rule>();
            var detailRules = new ArrayList<Rule>();
            for(var rule: this.validationCheck.getDetailRules()){
                var newCheck = new Rule();
                BeanUtils.copyProperties(rule, newCheck);
                newCheck.setCompileExpression(MVEL.compileExpression(newCheck.getExpression()));
                detailRules.add(newCheck);
            }
            for(var rule: this.validationCheck.getHeaderRules()){
                var newCheck = new Rule();
                BeanUtils.copyProperties(rule, newCheck);
                newCheck.setCompileExpression(MVEL.compileExpression(newCheck.getExpression()));
                headerRules.add(newCheck);
            }
            newValidationCheck.setDetailRules(detailRules);
            newValidationCheck.setHeaderRules(headerRules);
            this.setValidationCheck(newValidationCheck);
        }
        var checkParams = new HashMap<>();
        checkParams.put(Constants.CONTEXT_VAR_CRE_HEADER, gppFlux.getFirst().getHeader());
        checkParams.put(Constants.CONTEXT_VAR_CRE_DETAIL, gppFlux.getFirst().getDetail());
        checkParams.put(Constants.CONTEXT_VAR_DEBIT_VALUE, Constants.BI_DEBIT_VALUES);
        checkParams.put(Constants.CONTEXT_VAR_CREDIT_VALUE, Constants.BI_CREDIT_VALUES);
        checkParams.put(Constants.CONTEXT_VAR_CD_OPER_VALUE, Constants.BI_CD_OPER_VALUE);
        checkParams.put(Constants.CONTEXT_VAR_CD_TYP_FEE_VALUE, Constants.BI_CD_TYP_FEE_VALUE);
        checkParams.put(Constants.CONTEXT_VAR_LN_TYP_CPT_VALUE, Constants.BI_LN_TYP_CPT_VALUE);
        checkParams.put(Constants.CONTEXT_VAR_MVELUTIL_FUNCTION, MvelUtil.class);
        
        var headerMap = this.validationCheck.getHeaderRules().stream()
                .filter(rule -> !MVEL.executeExpression(rule.getCompileExpression(), checkParams, boolean.class))
                .collect(Collectors.toMap(rule -> rule, rule-> gppFlux.getFirst().getHeader().get(rule.getName())));
        var detailOneMap = this.validationCheck.getDetailRules().stream()
                .filter(rule -> !MVEL.executeExpression(rule.getCompileExpression(), checkParams, boolean.class))
                .collect(Collectors.toMap(rule -> rule, rule-> gppFlux.getFirst().getDetail().get(rule.getName())));
        // Set the second detail in the context
        checkParams.put(Constants.CONTEXT_VAR_CRE_DETAIL, gppFlux.getSecond().getDetail());
        var detailTwoMap = this.validationCheck.getDetailRules().stream()
                .filter(rule -> !MVEL.executeExpression(rule.getCompileExpression(), checkParams, boolean.class))
                .collect(Collectors.toMap(rule -> rule, rule-> gppFlux.getSecond().getDetail().get(rule.getName())));
        
        var result = new ValidationResult();
        result.setNumCre(gppFlux.getFirst().getHdNumcre());
        result.setStatus(!headerMap.isEmpty() || !detailOneMap.isEmpty() || !detailTwoMap.isEmpty());
        result.setHeaderErrorRules(headerMap);
        result.setDetailOneErrorRules(detailOneMap);
        result.setDetailTwoErrorRules(detailTwoMap);
        return result;
    }
    
    public boolean executeExceptionCheck(CreGPPFlux creGppFlux) {
        if(this.exceptionCheck.getCompileExpression() == null){
            // ExceptionCheck
            var newExceptionCheck = new Rule();
            BeanUtils.copyProperties(this.getExceptionCheck(), newExceptionCheck);
            newExceptionCheck.setCompileExpression(MVEL.compileExpression(newExceptionCheck.getExpression()));
            this.setExceptionCheck(newExceptionCheck);
        }
        var checkParams = new HashMap<>();
        checkParams.put(Constants.CONTEXT_VAR_CRE_DETAIL, creGppFlux.getDetail());
        return MVEL.executeExpression(this.exceptionCheck.getCompileExpression(), checkParams, boolean.class);
    }

    /**
     *
     * @param creGppFlux
     * @return DEBIT or CREDIT or null if error
     */
    public RuleRange executeRdjbiCheck(CreGPPFlux creGppFlux){
        if(this.rdjbiCheck.getCompileExpression() == null){
            var newRdjbiCheck = new Rule();
            BeanUtils.copyProperties(this.getRdjbiCheck(), newRdjbiCheck);
            newRdjbiCheck.setCompileExpression(MVEL.compileExpression(newRdjbiCheck.getExpression()));
            this.setRdjbiCheck(newRdjbiCheck);
        }
        var checkParams = new HashMap<>();
        checkParams.put(Constants.CONTEXT_VAR_CRE_HEADER, creGppFlux.getHeader());
        checkParams.put(Constants.CONTEXT_VAR_CRE_DETAIL, creGppFlux.getDetail());
        checkParams.put(Constants.CONTEXT_VAR_MVELUTIL_FUNCTION, MvelUtil.class);
        checkParams.put(Constants.CONTEXT_VAR_RULE_RANGE, RuleRange.class);
        checkParams.put(Constants.CONTEXT_VAR_DEBIT_VALUE, Constants.BI_DEBIT_VALUES);
        checkParams.put(Constants.CONTEXT_VAR_CREDIT_VALUE, Constants.BI_CREDIT_VALUES);
        return MVEL.executeExpression(this.rdjbiCheck.getCompileExpression(), checkParams, RuleRange.class);
    }

    /**
     * 
     * @param creGPPFlux
     * @return DEBIT or CREDIT or null if error
     */
    public RuleRange executeMetdcCheck(CreGPPFlux creGPPFlux){
        if(this.metdcCheck.getCompileExpression() == null){
            var newMetdcCheck = new Rule();
            BeanUtils.copyProperties(this.getMetdcCheck(), newMetdcCheck);
            newMetdcCheck.setCompileExpression(MVEL.compileExpression(newMetdcCheck.getExpression()));
            this.setMetdcCheck(newMetdcCheck);
        }
        var checkParams = new HashMap<>();
        checkParams.put(Constants.CONTEXT_VAR_CRE_HEADER, creGPPFlux.getHeader());
        checkParams.put(Constants.CONTEXT_VAR_CRE_DETAIL, creGPPFlux.getDetail());
        checkParams.put(Constants.CONTEXT_VAR_MVELUTIL_FUNCTION, MvelUtil.class);
        checkParams.put(Constants.CONTEXT_VAR_RULE_RANGE, RuleRange.class);
        checkParams.put(Constants.CONTEXT_VAR_DEBIT_VALUE, Constants.ME_DEBIT_VALUES);
        checkParams.put(Constants.CONTEXT_VAR_CREDIT_VALUE, Constants.ME_CREDIT_VALUES);
        checkParams.put(Constants.CONTEXT_VAR_LN_TYP_CPT_VALUE, Constants.ME_LN_TYP_CPT_VALUE);
        return MVEL.executeExpression(this.metdcCheck.getCompileExpression(), checkParams, RuleRange.class);
    }

    /**
     * 
     * @param creGPPFlux
     * @param mappingFunctions
     * @return true if there is KO case
     */
    public boolean executeMappingCheck(CreGPPFlux creGPPFlux, MappingFunctions mappingFunctions){
        // Compile referential rule
        if( this.referentialCheck.getCompileExpression() == null){
            var newRefCheck = new Rule();
            BeanUtils.copyProperties(this.getReferentialCheck(), newRefCheck);
            newRefCheck.setCompileExpression(MVEL.compileExpression(newRefCheck.getExpression()));
            this.setReferentialCheck(newRefCheck);
        }
        // Compile mapping rules 
        if(!this.mappingCheck.isEmpty() && this.mappingCheck.get(0).getCompileExpression() == null){
            var newMappingCheck = new ArrayList<Rule>();
            for(var rule: this.mappingCheck){
                var newCheck = new Rule();
                BeanUtils.copyProperties(rule, newCheck);
                newCheck.setCompileExpression(MVEL.compileExpression(newCheck.getExpression()));
                newMappingCheck.add(newCheck);
            }
            this.setMappingCheck(newMappingCheck);
        }
        // Run in MVEL
        var checkParams = new HashMap<>();
        checkParams.put(Constants.CONTEXT_VAR_CRE_HEADER, creGPPFlux.getHeader());
        checkParams.put(Constants.CONTEXT_VAR_CRE_DETAIL, creGPPFlux.getDetail());
        checkParams.put(Constants.CONTEXT_VAR_MAPPING_FUNCTION, mappingFunctions);
        return this.mappingCheck
                .stream()
                .map(rule -> MVEL.executeExpression(rule.getCompileExpression(), checkParams, boolean.class))
                .reduce(MVEL.executeExpression(this.referentialCheck.getCompileExpression(), checkParams, boolean.class), Boolean::logicalOr);
    }
    
    
    
    
}
