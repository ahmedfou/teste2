package com.cacib.trecca.rule;

import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
public class ValidationRule {
    private List<Rule> headerRules;
    private List<Rule> detailRules;
}
