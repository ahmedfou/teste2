package com.cacib.trecca.rule;

import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
public class GarnishesRule {
    private String condition;
    private List<Rule> rules;
}
