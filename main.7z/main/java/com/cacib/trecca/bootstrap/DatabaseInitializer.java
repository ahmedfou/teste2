package com.cacib.trecca.bootstrap;

import com.cacib.trecca.service.EventService;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;

@Configuration
@ConditionalOnProperty(value = "profile.test.enable", havingValue = "true", matchIfMissing = true)
public class DatabaseInitializer {

    @Bean
    CommandLineRunner init(EventService eventService) {
        return args -> eventService.publishLoadRefWhenAppBootEvent();
    }
}
