package com.cacib.trecca.repository;

import com.cacib.trecca.domain.Tiers;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface TiersRepository extends JpaRepository<Tiers, String> {
    Tiers findByCodTiersRicosSc(String refCod);
}
