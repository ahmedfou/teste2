package com.cacib.trecca.domain;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotNull;

@Entity
@Table(name = "REF_TIERS")
@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
public class Tiers {

    @Id
    @Column(name = "ID_TIERS", length = 10, unique = true)
    @NotNull
    private String idTiers;

    @Column(name = "COD_SOC_CA", length = 5)
    private String codSocCa;

    @Column(name = "COD_TIERS_RICOS_SC", length = 12, unique = true)
    private String codTiersRicosSc;
}
