package com.cacib.trecca.service;

import com.cacib.trecca.config.ApplicationProperties;
import jakarta.annotation.PostConstruct;
import jakarta.annotation.PreDestroy;
import lombok.RequiredArgsConstructor;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.producer.*;
import org.springframework.boot.autoconfigure.kafka.KafkaProperties;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.io.Serializable;
import java.util.Properties;
import java.util.UUID;

import static org.apache.kafka.clients.CommonClientConfigs.SECURITY_PROTOCOL_CONFIG;
import static org.apache.kafka.common.config.SaslConfigs.SASL_JAAS_CONFIG;
import static org.apache.kafka.common.config.SaslConfigs.SASL_MECHANISM;
import static org.apache.kafka.common.config.SslConfigs.SSL_TRUSTSTORE_LOCATION_CONFIG;

/**
 * KafkaProducerProcess is component that will be used to send messages to a kafka
 * topic
 */
@RequiredArgsConstructor
@Component
@Slf4j
public class KafkaProducerProcess implements Serializable {


    private final KafkaProperties kafkaProperties;
    /**
     * The kafka Producer instance that will be instantiated during the start up
     */
    protected Producer kafkaProducer;

    /**
     * the topic name that will used to publish message
     */
    private String topic = "";

    /**
     * Initialization method that will triggered after the creation of KafkaProducerProcess
     *
     * @throws IOException when the the producer properties file doesn't exist
     */
    @PostConstruct
    public void initProducer() throws IOException {
        Properties properties = new Properties();

        if (ObjectUtils.isNotEmpty(kafkaProperties.getConsumer().getProperties().get(SSL_TRUSTSTORE_LOCATION_CONFIG))) {
            properties.put(SSL_TRUSTSTORE_LOCATION_CONFIG,
                    kafkaProperties.getConsumer().getProperties().get(SSL_TRUSTSTORE_LOCATION_CONFIG));
        }
        if (ObjectUtils.isNotEmpty(kafkaProperties.getConsumer().getSecurity().getProtocol())) {
            properties.put(SECURITY_PROTOCOL_CONFIG, kafkaProperties.getConsumer().getSecurity().getProtocol());
        }
        if (ObjectUtils.isNotEmpty(kafkaProperties.getConsumer().getProperties().get(SASL_MECHANISM))) {
            properties.put(SASL_MECHANISM, kafkaProperties.getProducer().getProperties().get(SASL_MECHANISM));
        }
        if (ObjectUtils.isNotEmpty(kafkaProperties.getConsumer().getProperties().get(SASL_JAAS_CONFIG))) {
            properties.put(SASL_JAAS_CONFIG, kafkaProperties.getConsumer().getProperties().get(SASL_JAAS_CONFIG));
        }
        properties.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, kafkaProperties.getConsumer().getBootstrapServers());
        properties.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, kafkaProperties.getProducer().getKeySerializer());
        properties.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, kafkaProperties.getProducer().getValueSerializer());

        log.debug("Properties {}", properties);
        kafkaProducer = new KafkaProducer(properties);
    }

    /**
     * this method will be used to send message to the configured topic
     *
     * @param message is the message to be sent
     */
    public void send(String topic, String message) {
        ProducerRecord record = new ProducerRecord(topic, message);
        log.debug("Sending message {}", record);
            kafkaProducer.send(record, new Callback() {
                @SneakyThrows
                @Override
                public void onCompletion(RecordMetadata metadata, Exception exception) {
                    if (exception == null) {
                        log.debug("Record successfully transferred: topic {},partition {},offset{},timestamp{}",
                                metadata.topic(), metadata.partition(), metadata.offset(), metadata.timestamp());
                    } else {
                        log.error("an error occurred", exception);
                    }
                }
            });
    }

    /**
     * PreDestroy method that will clean up the producer connection before instance destruction
     */
    @PreDestroy
    public void shutdown() {
        log.info("Shutdown hook received, KafkaProducerProcess will be destroyed");
        kafkaProducer.flush();
        kafkaProducer.close();
    }

    /**
     *
     * @return a unique identifier
     */
    protected String getUUID() {
        return UUID.randomUUID().toString();
    }
}
