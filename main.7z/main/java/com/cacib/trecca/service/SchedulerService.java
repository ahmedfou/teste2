package com.cacib.trecca.service;

import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@Component
public class SchedulerService {

    private final EventService eventService;

    @Scheduled(cron = "${cacib.trecca.referential.tiers.archive-cron}")
    public boolean scheduleTiersLoading() {
        return eventService.publishLoadRefWhenAppRunEvent();
    }
}
