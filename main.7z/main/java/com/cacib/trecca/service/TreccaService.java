package com.cacib.trecca.service;

import com.cacib.trecca.config.ApplicationProperties;
import com.cacib.trecca.config.Constants;
import com.cacib.trecca.core.CreGPPFunctions;
import com.cacib.trecca.storage.StorageService;
import com.cacib.trecca.storage.model.FsFileLocation;
import com.cacib.trecca.util.FileUtil;
import jakarta.mail.MessagingException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.kafka.clients.consumer.*;
import org.apache.kafka.common.TopicPartition;
import org.apache.kafka.common.header.Header;
import org.springframework.stereotype.Service;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.StandardOpenOption;
import java.time.Duration;
import java.util.Collection;
import java.util.List;

@Slf4j
@Service
@RequiredArgsConstructor
public class TreccaService {

    private final StorageService storageService;
    private final TiersService tiersService;
    private final CreGPPService creGPPService;
    private final CreGPPFunctions gppFunctions;
    private final MessageService messageService;
    private final KafkaConsumer<String, String> kafkaConsumerApi;
    private final KafkaConsumer<String, String> kafkaConsumerElisa;

//	@Autowired
//	private final KafkaTemplate<String, String> kafkaTemplate;

    private final ApplicationProperties applicationProperties;

    private final MailService mailService;

    private final KafkaProducerProcess kafkaProducerProcess;

    private void doCommitSync(KafkaConsumer<String, String> kafkaConsumer) {
        try {
            kafkaConsumer.commitSync(Duration.ofSeconds(5));
            log.info("Successfully committed");
        } catch (CommitFailedException exception) {
            log.error("An error  occurred while committing", exception);
        }
    }

    private void subscribe(KafkaConsumer<String, String> kafkaConsumer, List<String> topics) {

        log.info("Subscribing to topic {}", topics);

        var start = System.currentTimeMillis();
        kafkaConsumer.subscribe(topics, new ConsumerRebalanceListener() {
            @Override
            public void onPartitionsRevoked(Collection<TopicPartition> partitions) {
                log.info("Partitions {} revoked, committing", partitions);
                if (!partitions.isEmpty()) {
                    TreccaService.this.doCommitSync(kafkaConsumer);
                }
            }

            @Override
            public void onPartitionsAssigned(Collection<TopicPartition> partitions) {
                var end = System.currentTimeMillis();
                log.info("Partitions assigned on topic {} after {} milliseconds", topics, end - start);
                log.info("Assigned partitions are:");
                partitions.forEach(partition -> log.info("{} - {}", partition.topic(), partition.partition()));
            }
        });
    }

    private void waitForMs(long duration, String message) {
        log.warn(message + ": {}", duration);
        try {
            Thread.sleep(duration);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }

    private void startConsuming(KafkaConsumer<String, String> kafkaConsumer,
                                StringBuilder combinedRecords,
                                StringBuilder errors) throws IOException {
        log.info("Start consuming");
        var totalProcessed = 0;
        var count = 0;

        kafkaConsumer.assignment().forEach(assignment -> log.info("Assignment for topic {} - partition {}", assignment.topic(), assignment.partition()));
        do {
            var records = kafkaConsumer.poll(Duration.ofSeconds(applicationProperties.getKafka().getPollDuration()));
            count = records.count();
            if (count > 0) {
                totalProcessed += count;

                log.info("Reading {} records", count);

                // archiver les records
                records.forEach(record -> combinedRecords.append(record.value()));

                this.processRecords(records, combinedRecords, errors);

                this.doCommitSync(kafkaConsumer);
            }
        } while (count != 0);

        if (totalProcessed > 0) {
            log.info("Number of processed messages: {}", totalProcessed);
        } else {
            log.warn("No message was processed.");
            return;
        }
    }

    private void sendToS3(String biCre) throws IOException {
        var fileName = FileUtil.generateUniqueFileName("CRE_RDJ_BI_", "dat");
        var file = new File(System.getProperty("java.io.tmpdir"), fileName).toPath();
        Files.writeString(file, biCre, StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING, StandardOpenOption.WRITE);
        var location = new FsFileLocation(applicationProperties.getStorage().getBucket().getExportName(), applicationProperties.getExport().getRdjBiPath(), fileName);
        var uploadResult = storageService.uploadFile(location, file.toFile());
        if (!uploadResult.isSuccess()) {
            log.warn("Upload of file {} was not successful. Reason: {}", file.toFile().getAbsolutePath(), String.join(System.lineSeparator(), uploadResult.getMessages()));
            log.warn("File content : {}", Files.readString(file));
        }
        Files.deleteIfExists(file);
    }

    public void sendRejects(String errors) {
        log.info("Sending rejects to topic {}", applicationProperties.getKafka().getTopic().getRejectGpp());
        kafkaProducerProcess.send(applicationProperties.getKafka().getTopic().getRejectGpp(), errors);
    }

    private void sendRejectionEmail(String errors) {
        var listErrorsFiles = gppFunctions.getErrorFileNameFromString(errors.toString());
        log.info("Liste des nom des fichiers d'erreur {}", listErrorsFiles);
        // TODO faire un mail avec les fichiers d'erreur dont les noms sont dans la liste precedente
        var files = listErrorsFiles.stream().map(File::new).toList();
        try {
            mailService.sendMultipartEmail("TRECCA - Erreurs", "Liste des fichiers d'erreur", files, applicationProperties.getMail().getFrom(), applicationProperties.getMail().getTo(), applicationProperties.getMail().getCc());
        } catch (MessagingException e) {
            log.error("An error occurred while sending email.");
        }
    }

    private void archiveRecords(String records, String topic) {
        log.info("Archiving records to topic {}", topic);
        kafkaProducerProcess.send(topic, records);
    }

    private void generateSgoTdcOutputs(String biCre) {
        log.info("generate SgoTdc Outputs ", biCre);
    }

    private void processRecord(ConsumerRecord<String, String> consumerRecord, final StringBuilder combinedRecords,
                               final StringBuilder errors) {
        log.info("Message read from partition {} with key {}, offset {}, timestamp {}, - Message {}",
                consumerRecord.partition(), consumerRecord.key(), consumerRecord.offset(), consumerRecord.timestamp(),
                consumerRecord.value());
        var headers = consumerRecord.headers();
        if (headers != null) {
            headers.forEach(header -> log.info("Header {} with value {}", header.key(), new String(header.value())));
        }

        // Todo: Get CRE ID
        var result = creGPPService.processCre(consumerRecord.value());
        var biStr = result.getRdjbi();
        var tdcStr = result.getMetdc();

        if (result.getErrorFileName() != null) {
            errors.append(result.getErrorFileName());
        }

        if (!StringUtils.isBlank(tdcStr) && applicationProperties.getSendTdc()) {
            log.info("Sending message {} to MQ", tdcStr);
            messageService.sendMessage(tdcStr, true);
        } else if (StringUtils.isBlank(tdcStr)) {
            log.warn("TDC is blank or empty.");
        } else {
            log.warn("Skipping sending TDC output.");
        }

        if (!StringUtils.isBlank(biStr)) {
            // TODO: Write to the file as they are produced to avoid OutOfMemoryError
            combinedRecords.append(biStr);
        } else {
            log.warn("BI CRE is empty.");
        }
    }

    private void processRecords(ConsumerRecords<String, String> consumerRecords, final StringBuilder combinedRecords,
                                final StringBuilder errors) {

        consumerRecords.forEach(consumerRecord -> {
            Header headerHdEntity = consumerRecord.headers().lastHeader(Constants.HD_ENTITY);
            if (headerHdEntity != null && new String(headerHdEntity.value()).equals(Constants.HD_ENTITY_TRECCA)) {
                log.info("Processing TRECCA CRE (HD_ENTITY): {}", new String(headerHdEntity.value()));
                this.processRecord(consumerRecord, combinedRecords, errors);
            }
        });
        //consumerRecords.forEach(consumerRecord -> this.processRecord(consumerRecord, biCre, errors));
    }

//	public void microVacation() throws IOException {
//		log.info("Starting process");
//		this.subscribe(kafkaConsumer, List.of(applicationProperties.getKafka().getTopic().getCregpp()));
//		this.waitForMs(10000L, "Waiting for subscription for topics %s".formatted(applicationProperties.getKafka().getTopic().getCregpp()));
//		this.startConsuming();
//		this.waitForMs(3000L, "Waiting before unsubscribe from topic %s".formatted(applicationProperties.getKafka().getTopic().getCregpp()));
//		kafkaConsumer.unsubscribe();
//		log.info("Leaving process");
//	}

    public void proceedStartConsuming(
            KafkaConsumer<String, String> kafkaConsumer,
            String topic,
            StringBuilder combiendRecords,
            StringBuilder errors)
            throws IOException {
        this.subscribe(kafkaConsumerApi, List.of(topic));
        this.waitForMs(10000L, "Waiting for subscription for topics %s".formatted(topic));
        this.startConsuming(kafkaConsumerApi, combiendRecords, errors);
    }

    public void microVacation() throws IOException {
        log.info("Starting process");
        var combiendRecords = new StringBuilder();
        var errors = new StringBuilder();
        // etape 1 : lire topic GPP
        proceedStartConsuming(kafkaConsumerApi, applicationProperties.getKafka().getTopic().getCregpp(),combiendRecords,errors);
        // etape 2 : archive dans le topic archive GPP
        archiveRecords(combiendRecords.toString(), applicationProperties.getKafka().getTopic().getArchiveGpp());
        // etape 3 : lire topic reprocessGpp
        proceedStartConsuming(kafkaConsumerApi, applicationProperties.getKafka().getTopic().getReprocessGpp(),combiendRecords,errors);
        // etape 4 : fusion des deux ensembles : done in combiendReocrds
        // etape 5 : execution des controls : done in processRecords
        // etape 6 et 7 : envois des rejets dans le topic reject + send email
        if (!errors.isEmpty()) {
            sendRejects(errors.toString());
            sendRejectionEmail(errors.toString());
        }
        // etape 8 : generation SGO TDC outputs
        generateSgoTdcOutputs(combiendRecords.toString());
        // etape 9 : Archive dans le topic TRECCA sgoTdc
        archiveRecords(combiendRecords.toString(), applicationProperties.getKafka().getTopic().getSgotdc());
        // etape 10 : lire topic reporcess sgotdc
        proceedStartConsuming(kafkaConsumerApi, applicationProperties.getKafka().getTopic().getReprocessSgotdc(),combiendRecords,errors);
        // etape 11 : fusion des sortie Sgotdc --> already combiend in combiendRecords;
        // etape 12 : envois vers MQ series
        sendToMqSeries(combiendRecords.toString());
        // etape 13 : generation des sortie RDJ BI CASA
        generateRdjibicasaOutputs();
        // etape 14 :
        archiveRecords(combiendRecords.toString(), applicationProperties.getKafka().getTopic().getRdjbicasa());
        // etape 15 : lire topic reprocess Rdj BI CASA
        proceedStartConsuming(kafkaConsumerApi, applicationProperties.getKafka().getTopic().getReprocessRdjbicasa(),combiendRecords,errors);
        // etape 16 : envois des sortie Rdj bi casa -> already combiend in combiendRecords;
        // etape 17: Envois vers ECS
        sendToEcs(combiendRecords.toString());
        // etape 18 : unsubscribe des deux consumers
        kafkaConsumerElisa.unsubscribe();
        kafkaConsumerApi.unsubscribe();
        log.info("Leaving process");
    }

    private void sendToEcs(String toString) {
        log.info("Sending to ECS");
    }

    private void generateRdjibicasaOutputs() {
        log.info("Generate RDJ BI CASA outputs");
    }

    private void sendToMqSeries(String toString) {
        log.info("Send To Mq Series");
    }


    public void archiveReferential() {
        log.info("Archiving repositories");

        tiersService.getOldTiersFileName()
                .forEach(prefix -> {
                    var importBucket = applicationProperties.getStorage().getBucket().getImportName();
                    var archiveBucket = applicationProperties.getStorage().getBucket().getArchiveImportName();
                    log.info("Moving file {} from bucket {} to bucket {}.", prefix, importBucket, archiveBucket);
                    var moveResult = storageService.moveFile(importBucket, prefix, archiveBucket, prefix);
                    if (moveResult.isSuccess()) {
                        log.info("File {} successfully moved from bucket {} to bucket {}.", prefix, importBucket, archiveBucket);
                    } else {
                        log.warn("Unable to move file {} moved from bucket {} to bucket {}. Reason: {}", prefix, importBucket, archiveBucket, String.join(System.lineSeparator(), moveResult.getMessages()));
                    }
                });
    }
}
