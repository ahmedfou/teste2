package com.cacib.trecca.service;

import com.cacib.trecca.config.ApplicationProperties;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.jms.JmsException;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.stereotype.Component;

@Slf4j
@RequiredArgsConstructor
@Component
public class MessageService {

    private final JmsTemplate jmsTemplate;
    private final ApplicationProperties properties;

    public void sendMessage(String message, boolean lineByLine) {
        var queue = properties.getQueue();
        var queueName = "queue:///" + queue.getName() + "?targetClient=1";
        log.info("Sending message {} to queue {}", message, queueName);

        try {
            if(lineByLine) {
                message.lines().forEach(line -> {
                    jmsTemplate.convertAndSend(queueName, line);
                    log.info("Message[line] {} successfully sent to queue {}.", line, queueName);
                });
            } else {
                jmsTemplate.convertAndSend(queueName, message);
                log.info("Message {} successfully sent to queue {}.", message, queueName);
            }
        } catch (JmsException exception) {
            var error = String.format("Error when sending message \"%s\" to the queue \"%s\"", message, queueName);
            log.error(error, exception);

            throw new MessageServiceException(error, queueName, message);
        }
    }
}
