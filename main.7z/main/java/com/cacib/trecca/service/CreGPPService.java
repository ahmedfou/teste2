package com.cacib.trecca.service;

import com.cacib.trecca.config.Constants;
import com.cacib.trecca.core.MappingFunctions;
import com.cacib.trecca.model.CreGPPFlux;
import com.cacib.trecca.model.Field;
import com.cacib.trecca.model.OutputFlux;
import com.cacib.trecca.rule.GarnishesRule;
import com.cacib.trecca.rule.ValidationFlow;
import com.cacib.trecca.types.FlowToGenerate;
import com.cacib.trecca.types.RuleRange;
import com.cacib.trecca.util.ErrorCsvUtil;
import com.cacib.trecca.util.FileUtil;
import com.cacib.trecca.util.GPPUtil;
import com.cacib.trecca.util.MvelUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.io.ResourceLoader;
import org.springframework.data.util.Pair;
import org.springframework.stereotype.Service;

import java.util.HashMap;

@Slf4j
@Service
@RequiredArgsConstructor
public class CreGPPService {
    private final ResourceLoader resourceLoader;
    private final MappingFunctions mappingFunctions;
    
    
    /**
     * 
     * @param creStr
     * @return
     */
    public OutputFlux processCre(String creStr){
        // Prepare validation workflow
        var checkResource = resourceLoader.getResource(Constants.CLASS_PATH + Constants.CRE_GPP_VERIFICATION_FLOW_RULES_FILE_PATH);
        var validationFlow = FileUtil.readJsonFile(checkResource, ValidationFlow.class);
        // Prepare output
        var result = new OutputFlux("", "", "");
        // Check if the string structure of the CRE is correct 
        if(!validationFlow.executeSizeCheck(creStr)) {
            var errorFileName = FileUtil.generateUniqueFileName("","xlsx");
            ErrorCsvUtil.generateErrorExcelFile(ErrorCsvUtil.sizeCheckContent(creStr), errorFileName);
            result.setErrorFileName(errorFileName);
            return result;
        }
        // Transform into different GPP flux
        var creDescriptionResource = resourceLoader.getResource(Constants.CLASS_PATH + Constants.CRE_GPP_DESC_FILE_PATH);
        var fluxGPP = GPPUtil.transformStringIntoCreGPPFlux(creStr, creDescriptionResource);
        // Execute validation on different GPP flux
        var validationResult = validationFlow.executeValidationCheck(fluxGPP);

        if(validationResult.isStatus()) {
            var errorFileName = FileUtil.generateUniqueFileName("","xlsx");
            ErrorCsvUtil.generateErrorExcelFile(ErrorCsvUtil.validationCheckContent(validationResult), errorFileName);
            result.setErrorFileName(errorFileName);
            return result;
        }
        // Check if is an exception flow
        var processFirstFlow = whichFlowToGenerate(fluxGPP.getFirst(), validationFlow);
        var processSecondFlow = whichFlowToGenerate(fluxGPP.getSecond(), validationFlow);
        
        if(processFirstFlow.getFirst().equals(FlowToGenerate.NONE) && processSecondFlow.getFirst().equals(FlowToGenerate.NONE)){
            // TODO form the content of  the error file
            var errorFileName = FileUtil.generateUniqueFileName("","xlsx");
            result.setErrorFileName(errorFileName);
            return result;
        }
        
        result.setMetdc(processFirstFlow.getSecond().getMetdc().concat(processSecondFlow.getSecond().getMetdc()));
        result.setRdjbi(processFirstFlow.getSecond().getRdjbi().concat(processSecondFlow.getSecond().getRdjbi()));
        
        return result;
    }

    

    /**
     * 
     * @param creGPPFlux
     * @param validationFlow
     * @return
     */
    public Pair<FlowToGenerate, OutputFlux> whichFlowToGenerate(CreGPPFlux creGPPFlux, ValidationFlow validationFlow){
        // Prepare output
        var result = new OutputFlux("", "", "");
        FlowToGenerate check;
        // Check if is an exception flow
        var biRange = validationFlow.executeRdjbiCheck(creGPPFlux);
        var meRange = validationFlow.executeMetdcCheck(creGPPFlux);
        var exceptionCheck = validationFlow.executeExceptionCheck(creGPPFlux);
        var mappingCheck = validationFlow.executeMappingCheck(creGPPFlux, mappingFunctions);

        // Generation of both flow fail
        if(meRange.equals(RuleRange.ERROR) && biRange.equals(RuleRange.ERROR)){
            check = FlowToGenerate.NONE;
            return Pair.of(check, result);
        }

        // Je dois generer que le flow BI
        if(meRange.equals(RuleRange.ERROR)) {
            check = FlowToGenerate.BI_ONLY;
            if(mappingCheck) {
                check = FlowToGenerate.NONE;
                return Pair.of(check, result);
            }
            result.setRdjbi(generateBI(creGPPFlux, biRange));
            return Pair.of(check, result);
        }

        // Je dois generer que le flow ME
        if(biRange.equals(RuleRange.ERROR)) {
            check = FlowToGenerate.ME_ONLY;
            result.setMetdc(generateME(creGPPFlux, meRange));
            return Pair.of(check, result);
        }
        // les range sont debit ou credit pr BI et ME
        if(exceptionCheck) {
            // Only RDJBI flow to generate
            if(mappingCheck) {
                check = FlowToGenerate.NONE;
                return Pair.of(check, result);
            }
            check = FlowToGenerate.BI_ONLY;
            result.setRdjbi(generateBI(creGPPFlux, biRange));
            return Pair.of(check, result);
        }
        // Je peux generer les deux flow
        result.setMetdc(generateME(creGPPFlux, meRange));
        if(mappingCheck) {
            check = FlowToGenerate.ME_ONLY;
            return Pair.of(check, result);
        }
        result.setRdjbi(generateBI(creGPPFlux, biRange));
        check = FlowToGenerate.BOTH;
        return Pair.of(check, result);
    }

    
    
    /**
     * 
     * @param creGPPFlux
     * @param ruleRange
     * @return
     */
    public String generateME(CreGPPFlux creGPPFlux, RuleRange ruleRange){
        var contextParams = new HashMap<>();
        contextParams.put(Constants.CONTEXT_VAR_CRE_HEADER, creGPPFlux.getHeader());
        contextParams.put(Constants.CONTEXT_VAR_CRE_DETAIL, creGPPFlux.getDetail());
        contextParams.put(Constants.CONTEXT_VAR_MVELUTIL_FUNCTION, MvelUtil.class);

        var garnishesResource = resourceLoader.getResource(Constants.CLASS_PATH + Constants.ME_TDC_GARNISHES_RULES_FILE_PATH);
        var garnishesRules = FileUtil.readJsonFile(garnishesResource, GarnishesRule.class);

        var descriptionResource = resourceLoader.getResource(Constants.CLASS_PATH + Constants.ME_TDC_DESC_FILE_PATH);
        var descriptionFields = FileUtil.readJsonArrayFile(descriptionResource, Field.class);

        return GPPUtil.executeGarnishesRule(garnishesRules, ruleRange, contextParams, descriptionFields);
    }

    
    
    /**
     * 
     * @param creGPPFlux
     * @param ruleRange
     * @return
     */
    public String generateBI(CreGPPFlux creGPPFlux, RuleRange ruleRange){
        var contextParams = new HashMap<>();
        contextParams.put(Constants.CONTEXT_VAR_CRE_HEADER, creGPPFlux.getHeader());
        contextParams.put(Constants.CONTEXT_VAR_CRE_DETAIL, creGPPFlux.getDetail());
        contextParams.put(Constants.CONTEXT_VAR_MVELUTIL_FUNCTION, MvelUtil.class);
        contextParams.put(Constants.CONTEXT_VAR_MAPPING_FUNCTION, mappingFunctions);

        var garnishesResource = resourceLoader.getResource(Constants.CLASS_PATH + Constants.RDJ_BI_GARNISHES_RULES_FILE_PATH);
        var garnishesRules = FileUtil.readJsonFile(garnishesResource, GarnishesRule.class);

        var descriptionResource = resourceLoader.getResource(Constants.CLASS_PATH+Constants.RDJ_BI_DESC_FILE_PATH);
        var descriptionFields = FileUtil.readJsonArrayFile(descriptionResource, Field.class);

        return GPPUtil.executeGarnishesRule(garnishesRules, ruleRange, contextParams, descriptionFields);
    }


    

}
