package com.cacib.trecca.service;

import com.cacib.trecca.events.TreccaCustomEvent;
import com.cacib.trecca.types.EventStatus;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.stereotype.Service;

@Slf4j
@Service
@RequiredArgsConstructor
public class EventService {
    private final ApplicationEventPublisher eventPublisher;

    private boolean publishEvent(EventStatus eventType) {
        eventPublisher.publishEvent(new TreccaCustomEvent(this, eventType));
        log.info("===> Publish the event {}", eventType.toString());
        return true;
    }
    

    public boolean publishFailureEvent() {
        return this.publishEvent(EventStatus.LOAD_REF_FAILED);
    }

    public boolean publishSuccessEvent() {
        return this.publishEvent(EventStatus.LOAD_REF_SUCCEED);
    }
    public boolean publishLoadRefWhenAppBootEvent(){
        return this.publishEvent(EventStatus.LOAD_REF_WHEN_APP_BOOTING);
    }
    public boolean publishLoadRefWhenAppRunEvent(){
        return this.publishEvent(EventStatus.LOAD_REF_WHEN_APP_RUNNING);
    }
}
