package com.cacib.trecca.service;

import com.cacib.trecca.config.ApplicationProperties;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Component;
import org.thymeleaf.spring6.SpringTemplateEngine;

import jakarta.mail.MessagingException;
import jakarta.mail.internet.MimeMessage;
import java.io.File;
import java.nio.charset.StandardCharsets;
import java.util.List;

@RequiredArgsConstructor
@Slf4j
@Component
public class MailService {

    private static final String VAR_TEMPLATE_NAME = "";
    private static final String VAR_TITLE = "";

    private final JavaMailSender emailSender;


    private final SpringTemplateEngine templateEngine;

    private final ApplicationProperties applicationProperties;

    public void sendSimpleMessage(String from, String to, String cc, String subject, String text) {
        SimpleMailMessage message = new SimpleMailMessage();
        message.setFrom(from);
        message.setTo(to);
        message.setSubject(subject);
        message.setText(text);
        message.setCc(cc);
        emailSender.send(message);
    }

    /**
     * Envoi de mail
     *
     * @param subject     objet du mail
     * @param content     contenu du mail
     * @param isMultipart
     * @throws MessagingException si une erreur survient
     */
    public void sendEmail(String subject, String content, boolean isMultipart) throws MessagingException {

        if (log.isDebugEnabled()) {
            log.debug("Sending mail: from: {} to: {}, cc: {}", applicationProperties.getMail().getFrom(), applicationProperties.getMail().getTo(),
                    applicationProperties.getMail().getCc());
        }

        this.sendEmail(subject, content, isMultipart, applicationProperties.getMail().getFrom(), applicationProperties.getMail().getTo(),
                applicationProperties.getMail().getCc());
    }

    public void sendEmail(String subject, String content, boolean isMultipart, String from, String[] to, String[] cc)
            throws MessagingException {

        if (log.isDebugEnabled()) {
            log.debug("Sending mail: from: {} to: {}, cc: {}", from, to, cc);
        }

        MimeMessage mimeMessage = emailSender.createMimeMessage();
        MimeMessageHelper mimeMessageHelper = new MimeMessageHelper(mimeMessage, isMultipart, StandardCharsets.UTF_8.name());
        mimeMessageHelper.setFrom(from);
        mimeMessageHelper.setTo(to);
        if (cc != null && cc.length > 0) {
            mimeMessageHelper.setCc(cc);
        }
        mimeMessageHelper.setSubject(subject);
        mimeMessageHelper.setText(content, true);

        emailSender.send(mimeMessageHelper.getMimeMessage());
    }

    public void sendMultipartEmail(String subject, String content, List<File> files, String from, String[] to, String[] cc)
            throws MessagingException {
        MimeMessage mimeMessage = emailSender.createMimeMessage();
        MimeMessageHelper mimeMessageHelper = new MimeMessageHelper(mimeMessage, true, StandardCharsets.UTF_8.name());
        mimeMessageHelper.setFrom(from);
        mimeMessageHelper.setTo(to);
        if (cc != null && cc.length > 0) {
            mimeMessageHelper.setCc(cc);
        }
        mimeMessageHelper.setSubject(subject);
        mimeMessageHelper.setText(content, true);

        for (var file : files) {
            mimeMessageHelper.addAttachment(file.getName(), file);
        }

        emailSender.send(mimeMessageHelper.getMimeMessage());
    }
}
