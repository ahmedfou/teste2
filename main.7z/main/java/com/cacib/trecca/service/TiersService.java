package com.cacib.trecca.service;

import com.cacib.trecca.config.ApplicationProperties;
import com.cacib.trecca.config.Constants;
import com.cacib.trecca.domain.Tiers;
import com.cacib.trecca.repository.TiersRepository;
import com.cacib.trecca.storage.StorageService;
import com.cacib.trecca.storage.model.FsFileDetail;
import com.cacib.trecca.storage.model.FsFileLocation;
import com.cacib.trecca.web.rest.error.TreccaException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.io.File;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.concurrent.atomic.AtomicLong;

import static com.cacib.trecca.config.Constants.REF_DATE_TIME_PATTERN;

@Slf4j
@RequiredArgsConstructor
@Service
@Transactional(propagation = Propagation.REQUIRED)
public class TiersService {

    private final StorageService storageService;
    private final TiersRepository tiersRepository;
    private final ApplicationProperties applicationProperties;


    @Transactional(readOnly = true)
    public File downloadReferentialFileFromS3AndParseToTiersObject(String fileName) {
        var bucket = applicationProperties.getStorage().getBucket().getImportName();
        var path = applicationProperties.getReferential().getTiers().getPath();
        var destinationDir = System.getProperty("java.io.tmpdir");
        var file = new File(destinationDir, fileName);
        var location = new FsFileLocation(bucket, path, fileName);
        var downloadResult = storageService.downloadTo(location, destinationDir);
        if(!downloadResult.isSuccess()) {
            throw new TreccaException("Error while downloading file %s: %s".formatted(fileName, String.join(System.lineSeparator(), downloadResult.getMessages())));
        }

        log.info("Downloaded {} bytes for {}.", downloadResult.getResult(), fileName);
        return file;
    }

    public Tiers stringToTiers(String line) {
        var sizeMinimalRequired = Arrays.stream(new int[]{Constants.REFS_ID_TIERS_END_INDEX, Constants.REFS_COD_SOC_CA_END_INDEX, Constants.REFS_COD_TIERS_RICOS_SC_END_INDEX}).max().orElse(0);
        if (line == null || line.length() <= sizeMinimalRequired) return null;
        var tier = new Tiers();
        tier.setIdTiers(line.substring(Constants.REFS_ID_TIERS_START_INDEX, Constants.REFS_ID_TIERS_END_INDEX));
        tier.setCodSocCa(line.substring(Constants.REFS_COD_SOC_CA_START_INDEX, Constants.REFS_COD_SOC_CA_END_INDEX));
        tier.setCodTiersRicosSc(line.substring(Constants.REFS_COD_TIERS_RICOS_SC_START_INDEX, Constants.REFS_COD_TIERS_RICOS_SC_END_INDEX));
        return tier;
    }

    public boolean deleteAndSaveAll(File file) {
        var totalCount = new AtomicLong(0L);
        try (var fileStream = Files.lines(file.toPath(), StandardCharsets.ISO_8859_1)) {
            totalCount.set(fileStream.count());
        } catch (Exception exception) {
            log.error("An error occurred when counting lines in file {}", file.getName(), exception);
            return false;
        }

        final var savedTiers = new AtomicLong(0L);
        log.info("Deleting existing data if any");
        tiersRepository.deleteAll();

        try (var stream = Files.lines(file.toPath(), StandardCharsets.ISO_8859_1)) {
            log.info("Starting data load");
            var start = System.currentTimeMillis();
            // TODO: Find a way to treat by chunks
            stream.map(this::stringToTiers)
                    .forEach(tiers -> {
                        tiersRepository.save(tiers);
                        savedTiers.incrementAndGet();
                    });
            var end = System.currentTimeMillis();
            log.info("Loaded {} lines after {} milliseconds", savedTiers.get(), end - start);
            return savedTiers.get() == totalCount.get();
        } catch (Exception exception) {
            log.error("An error occurred when loading referential {} into database.", file.getName(), exception);
            return false;
        }
    }

    @Transactional(readOnly = true)
    public Tiers findByCodRicos(String tiersCodRicos) {
        return tiersRepository.findByCodTiersRicosSc(tiersCodRicos);
    }

    public String getMostRecentTiersFileName() {
        log.info("Getting most referential from bucket {}, directory {}", applicationProperties.getStorage().getBucket().getImportName(), applicationProperties.getReferential().getTiers().getPath());
        var listFilesResult = storageService.listFiles(applicationProperties.getStorage().getBucket().getImportName(), applicationProperties.getReferential().getTiers().getPath(), 10);
        if (!listFilesResult.isSuccess()) {
            throw new TreccaException(String.join(System.lineSeparator(), listFilesResult.getMessages()));
        }

        var listFilesContent = listFilesResult.getResult();
        return listFilesContent.stream()
                .map(line -> {
                    var lastIndex = line.getName().lastIndexOf('/');
                    return lastIndex >= 0 ? line.getName().substring(lastIndex + 1) : line.getName();
                })
                .filter(line -> line.matches(applicationProperties.getReferential().getTiers().getRegexp())).max(Comparator.naturalOrder())
                .orElse(null);
    }

    public List<String> getOldTiersFileName() {
        var listFilesResult = storageService.listFiles(applicationProperties.getStorage().getBucket().getImportName(), applicationProperties.getReferential().getTiers().getPath(), 10);
        if (!listFilesResult.isSuccess()) {
            throw new TreccaException(String.join(System.lineSeparator(), listFilesResult.getMessages()));
        }

        var listFilesContent = listFilesResult.getResult();
        var listTiersNames = listFilesContent.stream()
                .map(line -> {
                    var lastIndex = line.getName().lastIndexOf('/');
                    return lastIndex >= 0 ? line.getName().substring(lastIndex + 1) : line.getName();
                })
                .filter(line -> line.matches(applicationProperties.getReferential().getTiers().getRegexp()))
                .sorted(Comparator.reverseOrder()).toList();

        if (!listTiersNames.isEmpty()) { // Exclude the most recent from referentials to be archived
            listTiersNames = listTiersNames.subList(1, listTiersNames.size());
        }

        return listTiersNames;
    }

    public String getCurrentDayTiersFileName() {
        var date = new Date();
        var dateFormat = new SimpleDateFormat(REF_DATE_TIME_PATTERN);
        var todayRefName = applicationProperties.getReferential().getTiers().getFileNameTemplate().replace("{DATE}", dateFormat.format(date));

        var listFilesResult = storageService.listFiles(applicationProperties.getStorage().getBucket().getImportName(), applicationProperties.getReferential().getTiers().getPath(), 10);
        if (!listFilesResult.isSuccess()) {
            throw new TreccaException(String.join(System.lineSeparator(), listFilesResult.getMessages()));
        }

        var listFilesContent = listFilesResult.getResult();

        return listFilesContent.stream().map(FsFileDetail::getName).anyMatch(name -> name.equals(todayRefName)) ? todayRefName : null;
    }
}
