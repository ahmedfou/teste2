package com.cacib.trecca.service;

import lombok.Getter;

@Getter
public class MessageServiceException extends RuntimeException {

	private static final long serialVersionUID = 584868216538169748L;

	private final String queueName;

	private final String content;

	public MessageServiceException(String error, String queueName, String content) {
		super(error);
		this.queueName = queueName;
		this.content = content;
	}
}
