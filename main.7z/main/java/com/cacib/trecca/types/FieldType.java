package com.cacib.trecca.types;

public enum FieldType {
    ALPHANUMERIC,
    NUMERIC,
    DATE
}
