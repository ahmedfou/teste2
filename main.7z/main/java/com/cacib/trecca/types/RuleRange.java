package com.cacib.trecca.types;

public enum RuleRange {
    COMMON,
    DEBIT,
    CREDIT,
    ERROR
}
