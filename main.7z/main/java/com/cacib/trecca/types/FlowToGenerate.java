package com.cacib.trecca.types;

public enum FlowToGenerate {
    BI_ONLY,
    ME_ONLY,
    BOTH,
    NONE
}
