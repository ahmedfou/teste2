package com.cacib.trecca.types;

public enum EventStatus {
    LOAD_REF_FAILED,
    LOAD_REF_SUCCEED,
    LOAD_REF_WHEN_APP_BOOTING,
    LOAD_REF_WHEN_APP_RUNNING
}
