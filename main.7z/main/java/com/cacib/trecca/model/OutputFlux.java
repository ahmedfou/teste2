package com.cacib.trecca.model;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class OutputFlux {
    private String metdc;
    private String rdjbi;
    private String errorFileName;
}
