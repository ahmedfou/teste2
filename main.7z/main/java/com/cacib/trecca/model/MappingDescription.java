package com.cacib.trecca.model;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class MappingDescription {
    private String cdOper;
    private String amountTyp;
    private String lnTypCpt;
    private String cdTypFee;
    private String mapValue;
}
