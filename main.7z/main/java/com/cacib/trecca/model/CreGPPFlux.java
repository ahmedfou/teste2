package com.cacib.trecca.model;

import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Map;

@Data
@NoArgsConstructor
public class CreGPPFlux {
    private String hdNumcre;
    private Map<String, Field> header;
    private String inputHeader;
    private Map<String, Field> detail;
    private String inputDetail;
}
