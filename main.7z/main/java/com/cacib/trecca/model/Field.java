package com.cacib.trecca.model;

import com.cacib.trecca.types.FieldType;
import com.cacib.trecca.types.PadDirection;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Field {
    private String technicalName;
    private FieldType fieldType;
    private String value;
    private int position;
    private int length;
    private char padChar;
    private PadDirection padDirection;
}