package com.cacib.trecca.model;

import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Data
@NoArgsConstructor
public class CreGPP {
    private String hdNumcre;
    private Map<String, Field> header;
    private List<Map<String, Field>> details;

    public void addDetail(Map<String, Field> detail){
        if(this.details == null){
            this.details = new ArrayList<>();
        }
        this.details.add(detail);
    }
}
