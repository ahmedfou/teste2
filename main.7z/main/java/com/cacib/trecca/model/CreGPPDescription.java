package com.cacib.trecca.model;

import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
public class CreGPPDescription {
    private List<Field> headerDescription;
    private List<Field> detailDescription;
}
