package com.cacib.trecca.security;

import static org.springframework.http.HttpHeaders.AUTHORIZATION;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.Base64;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.authentication.AbstractAuthenticationProcessingFilter;
import org.springframework.security.web.util.matcher.RequestMatcher;

public class TcaAuthenticationFilter extends AbstractAuthenticationProcessingFilter {

    public TcaAuthenticationFilter(final RequestMatcher requiredAuth) {
        super(requiredAuth);
    }

    @Override
    public Authentication attemptAuthentication(HttpServletRequest request, HttpServletResponse response) throws AuthenticationException {
        var token = StringUtils.isNotBlank(request.getHeader(AUTHORIZATION)) ? request.getHeader(AUTHORIZATION) : null;

        if (token == null) {
            throw new BadCredentialsException("Invalid or missing token.");
        }

    	var requestAuthentication = this.prepareAuthenticationRequest(token);

        return getAuthenticationManager().authenticate(requestAuthentication);
    }

    @Override
    protected void successfulAuthentication(final HttpServletRequest request, final HttpServletResponse response, final FilterChain chain, final Authentication authResult) throws IOException, ServletException {
        SecurityContextHolder.getContext().setAuthentication(authResult);
        chain.doFilter(request, response);
    }
    
    private UsernamePasswordAuthenticationToken prepareAuthenticationRequest(String token) {
    	token = StringUtils.removeStart(token, "Bearer").trim();
        var decodedToken = new String(Base64.getDecoder().decode(token), StandardCharsets.UTF_8);
        var separatorCount = StringUtils.countMatches(decodedToken, ':');
        if (separatorCount != 1) {
            throw new BadCredentialsException("Invalid token");
        }

        var indexOfSeparator = decodedToken.indexOf(':');
        if (indexOfSeparator == 0 || indexOfSeparator == (decodedToken.length() - 1)) {
            throw new BadCredentialsException("Invalid token");
        }
        var split = decodedToken.split(":");
        var username = split[0];
        var password = split[1];
        return new UsernamePasswordAuthenticationToken(username, password);
    }
}
