package com.cacib.trecca.events;

import com.cacib.trecca.types.EventStatus;
import lombok.Getter;
import org.springframework.context.ApplicationEvent;

@Getter
public class TreccaCustomEvent extends ApplicationEvent {

	private static final long serialVersionUID = 3486907797564975856L;

	private final EventStatus eventStatus;

	public TreccaCustomEvent(Object source, EventStatus eventStatus) {
		super(source);
		this.eventStatus = eventStatus;
	}
}
