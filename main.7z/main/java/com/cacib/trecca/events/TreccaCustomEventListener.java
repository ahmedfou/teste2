package com.cacib.trecca.events;

import com.cacib.trecca.service.EventService;
import com.cacib.trecca.service.TiersService;
import com.cacib.trecca.types.EventStatus;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.io.FileUtils;
import org.springframework.context.ApplicationListener;
import org.springframework.stereotype.Component;

import java.io.IOException;

@Slf4j
@Component
@RequiredArgsConstructor
public class TreccaCustomEventListener implements ApplicationListener<TreccaCustomEvent> {
	private final TiersService tiersService;
	private final EventService eventService;

	public boolean loadReferentialFileWithName(String tiersFileName) {
		var tiersFile = tiersService.downloadReferentialFileFromS3AndParseToTiersObject(tiersFileName);
		log.info("Downloaded file is {}", tiersFile);

		var result = tiersService.deleteAndSaveAll(tiersFile);
		try {
			FileUtils.delete(tiersFile);
		} catch (IOException exception) {
			log.warn("An error occurred while deleting file {}", tiersFile.getName(), exception);
		}

		return result;
	}

	public void loadReferentialWhenApplicationIsBooting() {
		var mostRecentRefName = tiersService.getMostRecentTiersFileName();
		log.info("===> Application booting load referential {}", mostRecentRefName);
		if (mostRecentRefName == null || !loadReferentialFileWithName(mostRecentRefName)) {
			eventService.publishFailureEvent();
			return;
		}
		eventService.publishSuccessEvent();
	}

	public void loadReferentialWhenApplicationIsRunning() {
		var todayTiers = tiersService.getCurrentDayTiersFileName();
		log.info("===> Scheduled loading referential of name {}", todayTiers);
		if (todayTiers != null)
			loadReferentialFileWithName(todayTiers);
		eventService.publishSuccessEvent();
	}

	@Override
	public void onApplicationEvent(TreccaCustomEvent event) {
		if (event.getEventStatus() == EventStatus.LOAD_REF_WHEN_APP_RUNNING) {
			loadReferentialWhenApplicationIsRunning();
			return;
		}
		if (event.getEventStatus() == EventStatus.LOAD_REF_WHEN_APP_BOOTING) {
			loadReferentialWhenApplicationIsBooting();
		}
	}
}
