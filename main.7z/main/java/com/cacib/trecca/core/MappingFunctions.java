package com.cacib.trecca.core;

import com.cacib.trecca.config.Constants;
import com.cacib.trecca.model.MappingDescription;
import com.cacib.trecca.service.TiersService;
import com.cacib.trecca.util.FileUtil;
import com.cacib.trecca.util.MvelUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.io.ResourceLoader;
import org.springframework.stereotype.Component;

import java.util.Arrays;

@Slf4j
@Component
@RequiredArgsConstructor
public class MappingFunctions {
    private final TiersService tiersService;
    private final ResourceLoader resourceLoader;

    public String lnTypCreMapping(String cdOper, String amountType) {
        var resource = resourceLoader.getResource(Constants.CLASS_PATH + Constants.MAPPING_LNTYPCRE_FILE_PATH);
        var table = FileUtil.readJsonArrayFile(resource, MappingDescription.class);
        var findMap = table.stream().filter(elt -> elt.getAmountTyp().equals(amountType) && elt.getCdOper().equals(cdOper)).findFirst();
        return findMap.isPresent() ? findMap.get().getMapValue() : null;
    }

    public String liCreugMapping(String cdOper, String amountTyp, String lnTypCptParam, String cdTypFeeParam) {
        var lnTypCpt = MvelUtil.in(lnTypCptParam, Constants.BI_LN_TYP_CPT_VALUE) ? lnTypCptParam : "AUTRES";
        var cdTypFee = cdOper.equals("XBPOUT") && lnTypCptParam.equals("WASH") && MvelUtil.in(amountTyp, Arrays.asList("PRP_AMT_CRE_ATT", "PRP_AMT_DEB_ATT")) ? cdTypFeeParam : "*";

        var resource = resourceLoader.getResource(Constants.CLASS_PATH + Constants.MAPPING_LICREUG_FILE_PATH);
        var table = FileUtil.readJsonArrayFile(resource, MappingDescription.class);
        var findMap = table.stream().filter(elt -> elt.getCdOper().equals(cdOper) && elt.getAmountTyp().equals(amountTyp) && elt.getLnTypCpt().equals(lnTypCpt) && elt.getCdTypFee().equals(cdTypFee)).findFirst();
        return findMap.isPresent() ? findMap.get().getMapValue() : null;
    }

    public String lnTypTransMapping(String cdOper, String amountType) {
        var resource = resourceLoader.getResource(Constants.CLASS_PATH + Constants.MAPPING_LNTYPTRANS_FILE_PATH);
        var table = FileUtil.readJsonArrayFile(resource, MappingDescription.class);
        var findMap = table.stream().filter(elt -> elt.getAmountTyp().equals(amountType) && elt.getCdOper().equals(cdOper)).findFirst();
        return findMap.isPresent() ? findMap.get().getMapValue() : null;
    }
    
    public String referentialMapping(String amountTyp, String bookMarginMnt) {
        if(amountTyp.equals("PRP_AMT_DEB_BRE") || amountTyp.equals("PRP_AMT_CRE_BRE")) return "10039";
        var tiers = tiersService.findByCodRicos(bookMarginMnt);
        if(tiers == null) return null;
        return (tiers.getCodSocCa() == null || tiers.getCodSocCa().isBlank()) ? "99999" : tiers.getCodSocCa();
    }
}
