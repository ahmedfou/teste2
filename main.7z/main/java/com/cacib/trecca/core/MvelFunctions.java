package com.cacib.trecca.core;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import com.cacib.trecca.config.Constants;
import com.cacib.trecca.web.rest.error.TreccaException;

@Component
public class MvelFunctions {

    public <T>boolean in(T value, List<T> values) {
        return value != null && values.contains(value);
    }

    public String formatDate(String inputDate, String inputFormat, String outputFormat) {
        Date date;
        try {
            date = new SimpleDateFormat(inputFormat).parse(inputDate);
            return new SimpleDateFormat(outputFormat).format(date);
        } catch (ParseException e) {
            throw new TreccaException("Invalid date parsing format " + outputFormat + " for the date "+ inputDate);
        }
    }

    public String leftPad(String value, int size, char padChar) {
        return StringUtils.leftPad(value, size, padChar);
    }

    public String rightPad(String value, int size, char padChar) {
        return StringUtils.rightPad(value, size, padChar);
    }

    public String splitRegex(String params, String regex){
        return Arrays.stream(params.trim().split(regex)).reduce(String::concat).orElse("");
    }

    public boolean isNumeric(String value, int size){
        return value != null && value.matches(Constants.NUMERIC_REGEX) && value.length() == size;
    }

    public boolean isAlphaNumeric(String value, int size){
        return value != null && value.matches(Constants.ALPHA_NUMERIC_REGEX) && value.length() == size;
    }

    public boolean isNoRegularAlphaNumeric(String value, int size){
        return value != null && value.matches(Constants.NO_REGULAR_ALPHA_NUMERIC_REGEX) && value.length() == size;
    }

    public boolean isValidDate(String date, String dateFormat){
        if(date == null || dateFormat == null || dateFormat.length() != date.length()) return false;
        var sdf = new SimpleDateFormat(dateFormat);
        sdf.setLenient(false);
        try {
            sdf.parse(date);
            return true;
        } catch (ParseException e) {
            return false;
        }
    }

    public boolean isMatchSize(String value, int size){
        return value != null && value.length() == size;
    }

}
