package com.cacib.trecca.core;

import com.cacib.trecca.config.Constants;
import com.cacib.trecca.model.Field;
import com.cacib.trecca.types.PadDirection;
import lombok.RequiredArgsConstructor;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.data.util.Pair;
import org.springframework.stereotype.Component;

import java.util.*;
import java.util.regex.Pattern;

@Component
@RequiredArgsConstructor
public class CreGPPFunctions {

    public Pair<Boolean, Map<Integer, String[]>> isValidCreGPPString(String str){
        var result = new HashMap<Integer, String[]>();
        var index = 0;
        result.put(index++, new String[]{"Num", "Champ", "Message", "Valeur du CRE"});
        //Check the structure of the cre
        if(str == null){
            result.put(index, new String[]{"" + index, "CRE", "La structure du CRE devrait contenir 3 lignes un HEADER et 2 details. Pour l'instant c'est une chaine vide", ""});
            return Pair.of(false, result);
        }
        if(str.lines().count() != 3) {
            result.put(index, new String[]{"" + index, "CRE", "La structure du CRE devrait contenir 3 lignes un HEADER et 2 details. Il contient " + str.lines().count() + " ligne(s)", str});
            return Pair.of(false, result);
        }
        //Check the size
        var sizeCheck = str.lines().map(this::isCreGPPSizeCorrect).reduce(Boolean::logicalAnd).orElse(false);
        // Check the
        var hdNumCre = getCreHdNumcre(str.lines().findFirst().orElse(""));
        var hdNumCreCheck = str.lines().map(this::getCreHdNumcre).allMatch(cre -> cre.equals(hdNumCre));
        var countHeaderLine = str.lines().filter(this::isHeaderCreGPP).count();
        var countDetailLines = str.lines().filter(this::isDetailCreGPP).count();

        if(Boolean.FALSE.equals(sizeCheck)) {
            result.put(index, new String[]{"" + index++, "CRE", "La taille du HEADER doit etre de 2428 et celle des DETAILS est de 1096 (Voir la SFD)", str});
        }
        if(!hdNumCreCheck) {
            result.put(index, new String[]{"" + index++, "CRE", "Le champ HD_NUMCRE n'est pas le meme pour le header et les details (" + hdNumCre + ").", str});
        }
        if(countHeaderLine != 1) {
            result.put(index, new String[]{"" + index++, "HEADER", "Le CRE ne possede pas de header valide. Verifier la position du champ HD_NUMCRE", str});
        }
        if(countDetailLines != 2) {
            result.put(index, new String[]{"" + index, "DETAIL", "Le CRE ne possede pas de details valide. Verifier la position du champ HD_NUMCRE", str});
        }
        return Pair.of(sizeCheck && hdNumCreCheck && countHeaderLine == 1 && countDetailLines == 2, result);
    }

    public boolean isCreGPPSizeCorrect(String creGpp){
        return Arrays.asList(Constants.CRE_GPP_HEADER_SIZE, Constants.CRE_GPP_DETAIL_SIZE).contains(creGpp.length());
    }

    public boolean isHeaderCreGPP(String creGPP){
        return creGPP != null && creGPP.length() == Constants.CRE_GPP_HEADER_SIZE && creGPP.startsWith(Constants.CRE_HEADER_ID_TEXT, Constants.CRE_HEADER_ID_START_INDEX);
    }

    public boolean isDetailCreGPP(String creGPP){
        return creGPP != null && creGPP.length() == Constants.CRE_GPP_DETAIL_SIZE && !creGPP.startsWith(Constants.CRE_HEADER_ID_TEXT, Constants.CRE_HEADER_ID_START_INDEX);
    }

    public String getCreHdNumcre(String creGpp){
        if(creGpp.length() < Constants.CRE_HD_NUMCRE_END_INDEX) return null;
        return creGpp.substring(Constants.CRE_HD_NUMCRE_START_INDEX, Constants.CRE_HD_NUMCRE_END_INDEX);
    }
    
    public List<Field> mapOutputDescriptionToValues(Map<String, String> garnishesValues, List<Field> outputDescription){
        List<Field> result = new ArrayList<>();
        for(var descField: outputDescription){
            var field = new Field();
            BeanUtils.copyProperties(descField, field);
            var currentValue = garnishesValues.get(field.getTechnicalName());
            var taille = field.getLength();
            var padChar = field.getPadChar();
            if(currentValue != null) {
                var calValue = (field.getPadDirection().equals(PadDirection.LEFT)) ? StringUtils.leftPad(currentValue, taille, padChar) : StringUtils.rightPad(currentValue, taille, padChar);
                field.setValue(calValue);
                result.add(field);
            }
        }
        return result;
    }

    public List<String> getErrorFileNameFromString(String chaine){
        var result = new ArrayList<String>();
        var pattern  = Pattern.compile("\\w{17}.\\w{3}.xlsx");
        var matcher = pattern.matcher(chaine);
        while(matcher.find()){
            result.add(matcher.group());
        }
        return result;
    }
}
